# 实验六报告

> 学号：3225706008
> 
> 姓名：范馨霏
> 
> 指导老师：张凯斌
> 
> 实验日期：2025-04-10

## 一、实验目的

- 完成实验五中的L/R页面功能；
- 锻炼课堂所讲授的面向对象分析与设计能力；
- 实践编码能力

## 二、实验内容

- 依托教科书的第9章“数据管理”；
- 回顾实验三与实验四内容；
- 结合《课程指导》

完成本次实验。

## 三、实验要求

- Login/Registration System
  - 本次实验要求完成完整的登录/注册功能
- 基本需求
  - 三个UI Pages
    - L/R Page（实验五已进行）
      - 添加一个“角色”选项
        - 用户
        - 管理员
      - 输对用户名和密码后
        - 用户进入Home Page
        - 管理员进入Management Page
      - 如果登录信息不存在，提示进行“注册”
      - 连续3次输错密码后，关闭整个App
    - Registration Page
      - 引导用户输入注册信息
        - 用户名、性别、邮箱、密码、角色为必选项，其他自行设计
        - 需对用户输入内容进行形式判断，如数据类型等
          - 形式判断错误的，需要引导用户重新输入
      - 点击确认按钮后信息存入SQLite数据库
        - “用户”采用HarmonyOS的built-in加密存储功能
        - “管理员”采用自行加密模块处理后存储
    - Management Page
      - 此为管理员登录成功后可进入的页面
      - 具备“查询”按钮，点击返回整个注册数据库的信息
        - 跳转页面后用列表显示出来
          - 需解密后显示明文
  - 完成用例图和详细类图
    - 其他类型的图不要求
  - 完成编码实现
- 技术要求
  - 不能使用回调函数来完成异步编程，全部使用async/await形式
  - 必须有关键节点的日志输出



## 四、实验步骤

### 1. L/R Page

#### 1.1 截图展示

可以进行角色选择，需要先注册才能登录，如果登录信息不存在，提示进行“注册”，连续3次输错密码后，关闭整个App

![alt text](login.png){width=160px height=300px} ![alt text](notexist.png){width=160px height=300px} ![alt text](errorone.png){width=160px height=300px} ![alt text](errorthree.png){width=160px height=300px} ![alt text](closed.png){width=160px height=300px}

输出日志：
![alt text](loginlog.png){width=600px height=300px}
![alt text](loginlog2.png){width=600px height=150px}

输对用户名和密码后，用户进入Home Page，管理员进入Management Page

![alt text](home.png){width=160px height=300px} ![alt text](Management.png){width=160px height=300px}
#### 1.2 用例图与类图

![alt text](loginusage.png){width=300px height=300px}
![alt text](loginclass.png){width=600px height=300px}

#### 1.3 代码实现

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit';
import promptAction from '@ohos.promptAction';
import { RdbManager } from '../database/RDBManager';
import common from '@ohos.app.ability.common';

@Entry
@Component
struct LoginPage {
  @State username: string = ''; // 用户名状态
  @State password: string = ''; // 密码状态
  @State isLoggingIn: boolean = false; // 登录状态
  @State errorCount: number = 0; // 错误计数器
  @State role: 'user' | 'admin' = 'user'; // 角色状态

  private rdbManager = RdbManager.getInstance(getContext(this)); // 获取 RdbManager 实例

  // 登录方法
  async login() {
    console.log('开始登录流程');
    // 检查用户名和密码是否为空
    if (!this.username || !this.password) {
      promptAction.showToast({ message: '请输入用户名和密码或进行注册', duration: 2000 });
      return;
    }

    this.isLoggingIn = true;// 设置登录状态为true，防止重复登录
    console.log('正在进行登录验证');

    try {
      // 检查用户名是否存在
      console.log(`检查用户名: ${this.username}`);
      const userExists = await this.rdbManager.isUsernameTaken(this.username);

      // 如果用户名不存在
      if (!userExists) {
        promptAction.showToast({ message: '用户名不存在，请先注册', duration: 2000 });
        console.log(`用户名不存在`);
        return;
      }

      // 验证密码
      console.log(`验证用户: ${this.username} 的密码`);
      const isValid = await this.rdbManager.loginUser(this.username, this.password, this.role);

      // 如果验证成功
      if (isValid) {
        this.errorCount = 0; // 重置错误计数器
        console.log('登录验证成功');
        promptAction.showToast({ message: '登录成功', duration: 2000 });

        // 根据角色跳转到不同页面
        const targetPage = this.role === 'admin' ? 'pages/Management' : 'pages/Home';
        console.log(`跳转到页面: ${targetPage}`);

        // 跳转到目标页面
        router.pushUrl({
          url: targetPage,
          params: {
            username: this.username,
            role: this.role // 传递角色参数
          }
        }).catch((err: BusinessError) => {
          console.error(`导航失败: ${err.message}`);
        });
      } else {
        // 处理登录失败
        this.handleFailedAttempt();
      }
    } catch (error) {
      console.error('登录过程中发生错误:', error);
      promptAction.showToast({ message: '登录出错，请重试', duration: 2000 });
    } finally {
      this.isLoggingIn = false;
      console.log('登录流程结束');
    }
  }

  // 处理登录失败的方法
  private handleFailedAttempt() {
    this.errorCount++;// 增加错误计数
    console.log(`登录失败，错误次数: ${this.errorCount}`);

    // 如果错误次数达到3次
    if (this.errorCount >= 3) {
      console.log('错误次数过多，即将关闭应用');
      promptAction.showToast({
        message: '密码错误次数过多，应用即将关闭',
        duration: 2000
      });

      // 2秒后关闭应用
      setTimeout(() => {
        const context = getContext(this) as common.UIAbilityContext;
        context.terminateSelf()
          .then(() => console.info('应用已终止'))
          .catch((err: BusinessError) => {
            console.error(`终止应用失败: ${err.code} - ${err.message}`);
          });
      }, 2000);
    } else {
      // 显示剩余尝试次数提示信息
      promptAction.showToast({
        message: `密码错误（剩余尝试次数：${3 - this.errorCount}）`,
        duration: 2000
      });
    }
  }

  // 构建页面结构
  build() {
    Stack() {
      // 背景图片容器
      Image($r('app.media.Loginback')) // 背景图
        .width('100%')
        .height('100%')
        .objectFit(ImageFit.Cover) // 保持图片比例填满容器
        .opacity(0.15); // 设置透明度 0-1 (0为全透明，1为不透明)

      Column() {
        // 用户头像和登录表单
        Stack() {
          Column()
            .width(160)
            .height(160)
            .borderRadius(95)
            .backgroundColor('#e0e0e0');

          //头像
          Image($r('app.media.mainuser'))
            .width(150)
            .height(150)
            .margin(5)
            .borderRadius(100)
            .clip(true);
        }
        .width(190)
        .height(190)
        .margin({ bottom: 20 });

        // 用户名输入框
        TextInput({ placeholder: '请输入用户名' })
          .width('80%')
          .height(50)
          .margin({ bottom: 20 })
          .onChange((value: string) => {
            this.username = value;
          });

        // 密码输入框
        TextInput({ placeholder: '请输入密码' })
          .width('80%')
          .height(50)
          .type(InputType.Password)
          .margin({ bottom: 30 })
          .onChange((value: string) => {
            this.password = value;
          });

        // 角色选择区域
        Row() {
          // 用户角色单选按钮
          Radio({ value: 'user', group: 'role' })
            .checked(this.role === 'user')
            .onChange((checked: boolean) => {
              if (checked) {
                this.role = 'user';
                console.log('选择角色: 用户');
              }
            })
            .size({ width: 24, height: 24 });

          Text('用户')
            .fontSize(16)
            .margin({ left: 8 });

          // 管理员角色单选按钮
          Radio({ value: 'admin', group: 'role' })
            .checked(this.role === 'admin')
            .onChange((checked: boolean) => {
              if (checked) {
                this.role = 'admin';
                console.log('选择角色: 管理员');
              }
            })
            .size({ width: 24, height: 24 })
            .margin({ left: 20 });

          Text('管理员')
            .fontSize(16)
            .margin({ left: 8 });
        }
        .margin({ bottom: 20 });

        // 登录和注册按钮
        Row() {
          Button('登录')
            .width('40%')
            .height(50)
            .backgroundColor('#86AEC8')
            .onClick(() => {
              console.log('点击登录按钮');
              this.login();
            });

          Blank().width('10%'); // 间隔

          Button('注册')
            .width('40%')
            .height(50)
            .backgroundColor('#86AEC8')
            .onClick(() => {
              console.log('点击注册按钮');
              router.pushUrl({
                url: 'pages/Registration'
              }).catch((err: BusinessError) => {
                console.error(`导航失败: ${err.message}`);
              });
            });
        }
        .margin({ bottom: 20 })
        .justifyContent(FlexAlign.SpaceBetween)
        .width('80%');
      }
      .width('100%')
      .height('100%')
      .padding(20)
      .justifyContent(FlexAlign.Center);
    }
    .width('100%')
    .height('100%');
  }
}
```


### 2. Registration Page

#### 2.1 截图展示

引导用户输入注册信息：用户名、密码、性别、邮箱、密码、角色，自行设计加了个手机号，可对用户输入内容进行形式判断，可引导用户重新输入，全部正确后输出注册成功可以进行登录

![alt text](Registration.png){width=160px height=300px} ![alt text](yanzheng.png){width=160px height=300px} ![alt text](yanzheng2.png){width=160px height=300px} ![alt text](success.png){width=160px height=300px} 

日志输出：
![alt text](Registrationlog.png){width=600px height=300px} 
![alt text](Registrationlog2.png){width=600px height=300px} 
![alt text](Registrationlog3.png){width=600px height=150px} 

点击确认按钮后信息存入SQLite数据库，“用户”采用HarmonyOS的built-in加密存储功能使用AES对称密钥，“管理员”采用自行加密模块处理后存储使用RSA非对称密钥，具体体现在RDBManager页面中

#### 2.2 用例图与类图

![alt text](Registrationusage.png){width=400px height=500px} 
![alt text](Registrationclass.png){width=600px height=300px}

#### 2.3 代码实现

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
import { router } from '@kit.ArkUI'; // 引入路由模块
import { BusinessError } from '@kit.BasicServicesKit'; // 引入业务错误模块
import promptAction from '@ohos.promptAction'; // 引入提示操作模块
import { RdbManager } from '../database/RDBManager'; // 引入数据库管理类

@Entry // 标记为入口组件
@Component // 标记为组件
struct RegisterPage { // 定义注册页面组件
  @State username: string = ''; // 用户名状态
  @State password: string = ''; // 密码状态
  @State sex: 'male' | 'female' = 'male'; // 性别状态，默认为男
  @State phone: string = ''; // 手机号状态
  @State email: string = ''; // 邮箱状态
  @State isRegistering: boolean = false; // 注册状态
  @State role: 'user' | 'admin' = 'user'; // 角色状态


  private rdbManager = RdbManager.getInstance(getContext(this)); // 获取 RdbManager 单例实例

  private validateUsername(): boolean { // 验证用户名方法
    console.log('开始验证用户名');
    if (this.username.trim() === '') { // 检查用户名是否为空
      console.log('用户名不能为空');
      promptAction.showToast({ message: '用户名不能为空', duration: 2000 });
      return false;
    }
    const valid = /^[a-zA-Z0-9]{4,16}$/.test(this.username); // 验证用户名格式
    if (!valid) { // 如果验证失败
      console.log('用户名格式错误：4-16位字母或数字');
      promptAction.showToast({
        message: '用户名格式错误：4-16位字母或数字',
        duration: 2000
      });
    }
    console.log('用户名验证结果: ' + valid);
    return valid;
  }

  private validatePassword(): boolean { // 验证密码方法
    console.log('开始验证密码');
    if (this.password.trim() === '') { // 检查密码是否为空
      console.log('密码不能为空');
      promptAction.showToast({ message: '密码不能为空', duration: 2000 });
      return false; // 返回验证失败
    }
    const valid = this.password.length >= 6 && this.password.length <= 20; // 验证密码长度
    if (!valid) { // 如果验证失败
      console.log('密码格式错误：6-20位字符');
      promptAction.showToast({
        message: '密码格式错误：6-20位字符',
        duration: 2000
      });
    }
    console.log('密码验证结果: ' + valid);
    return valid;
  }

  private validatePhone(): boolean { // 验证手机号方法
    console.log('开始验证手机号');
    if (this.phone.trim() === '') { // 检查手机号是否为空
      console.log('手机号不能为空');
      promptAction.showToast({ message: '手机号不能为空', duration: 2000 });
      return false;
    }
    const valid = /^1[3-9]\d{9}$/.test(this.phone); // 验证手机号格式
    if (!valid) { // 如果验证失败
      console.log('手机号格式错误：请输入有效的手机号');
      promptAction.showToast({
        message: '手机号格式错误：请输入有效的手机号',
        duration: 2000
      });
    }
    console.log('手机号验证结果: ' + valid);
    return valid;
  }

  private validateEmail(): boolean { // 验证邮箱方法
    console.log('开始验证邮箱');
    if (this.email.trim() === '') { // 检查邮箱是否为空
      console.log('邮箱不能为空');
      promptAction.showToast({ message: '邮箱不能为空', duration: 2000 });
      return false;
    }
    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.email); // 验证邮箱格式
    if (!valid) { // 如果验证失败
      console.log('邮箱格式错误：请输入有效的邮箱地址');
      promptAction.showToast({
        message: '邮箱格式错误：请输入有效的邮箱地址',
        duration: 2000
      });
    }
    console.log('邮箱验证结果: ' + valid);
    return valid;
  }

  private validateRole(): boolean { // 验证角色方法
    console.log('开始验证角色');
    const valid = ['user', 'admin'].includes(this.role); // 验证角色是否有效
    if (!valid) { // 如果验证失败
      promptAction.showToast({
        message: '角色选择无效',
        duration: 2000
      });
    }
    console.log('角色验证结果: ' + valid);
    return valid;
  }


  private validateAll(): boolean {
    const errors: string[] = []; // 收集错误信息

    if (!this.validateUsername()) errors.push('用户名不能为空：4-16位字母或数字');
    if (!this.validatePassword()) errors.push('密码不能为空：6-20位字符');
    if (!this.validatePhone()) errors.push('手机号不能为空：请输入有效的手机号');
    if (!this.validateEmail()) errors.push('邮箱不能为空：请输入有效的邮箱地址');
    if (!this.validateRole()) errors.push('角色选择无效');

    if (errors.length > 0) {
      // 显示所有错误信息，每条信息占一行
      promptAction.showToast({
        message: errors.join('\n'),
        duration: 2000
      });
      return false;
    }
    return true;
  }

  async register() { // 注册方法
    console.log('开始注册流程');
    if (!this.validateAll()) { // 综合验证
      console.log('注册信息验证失败');
      return;
    }

    this.isRegistering = true; // 设置注册状态为true

    try {
      console.log(`注册用户: ${this.username}, 角色: ${this.role}`);
      const success = await this.rdbManager.registerUser( // 调用数据库管理类的注册用户方法
        this.username,
        this.password,
        this.sex,
        this.phone,
        this.email,
        this.role
      );

      if (success) { // 如果注册成功
        console.log('用户注册成功');
        promptAction.showToast({ message: '注册成功', duration: 2000 });
        router.back(); // 返回上一页
      } else {
        console.log('用户注册失败');
        promptAction.showToast({ message: '注册失败，请重试', duration: 2000 });
      }
    } catch (error) {
      console.error('注册过程中发生错误:', error); // 捕获注册过程中的错误并输出日志
      promptAction.showToast({ message: '注册出错，请重试', duration: 2000 });
    } finally {
      this.isRegistering = false; // 重置注册状态为false
      console.log('注册流程结束');
    }
  }

  build() {
    Stack() {
      //背景图片
      Image($r('app.media.loadingback'))
        .width('100%')
        .height('100%')
        .objectFit(ImageFit.Cover)
        .opacity(0.15);

      Column() {
        Stack() {
          Column()
            .width(160)
            .height(160)
            .borderRadius(95)
            .backgroundColor('#e0e0e0');

          //用户头像
          Image($r('app.media.mainuser'))
            .width(150)
            .height(150)
            .margin(5)
            .borderRadius(100)
            .clip(true);
        }
        .width(190)
        .height(190)
        .margin({ bottom: 20 });

        //用户名输入框
        TextInput({ placeholder: '请输入用户名:4-16位字母或数字' })
          .width('80%')
          .height(50)
          .margin({ bottom: 20 })
          .onChange((value: string) => {
            this.username = value;
          });

        //密码输入框
        TextInput({ placeholder: '请输入密码：6-20位字符' })
          .width('80%')
          .height(50)
          .type(InputType.Password)
          .margin({ bottom: 20 })
          .onChange((value: string) => {
            this.password = value;
          });

        //性别选择
        Row() {
          Radio({ value: 'male', group: 'sex' })
            .checked(this.sex === 'male')
            .onChange((checked: boolean) => {
              if (checked) {
                this.sex = 'male';
                console.log('选择性别: 男');
              }
            })
            .size({ width: 24, height: 24 });

          Text('男')
            .fontSize(16)
            .margin({ left: 8 });

          Radio({ value: 'female', group: 'sex' })
            .checked(this.sex === 'female')
            .onChange((checked: boolean) => {
              if (checked) {
                this.sex = 'female';
                console.log('选择性别: 女');
              }
            })
            .size({ width: 24, height: 24 })
            .margin({ left: 20 });

          Text('女')
            .fontSize(16)
            .margin({ left: 8 });
        }
        .margin({ bottom: 20 });

        //手机号输入框
        TextInput({ placeholder: '请输入手机号' })
          .width('80%')
          .height(50)
          .type(InputType.Number)
          .margin({ bottom: 20 })
          .onChange((value: string) => {
            this.phone = value;
          });


        //邮箱输入框
        TextInput({ placeholder: '请输入邮箱' })
          .width('80%')
          .height(50)
          .margin({ bottom: 30 })
          .onChange((value: string) => {
            this.email = value;
          });

        //身份选择区域
        Row() {
          Radio({ value: 'user', group: 'role' })
            .checked(this.role === 'user')
            .onChange((checked: boolean) => {
              if (checked) {
                this.role = 'user';
                console.log('选择角色: 用户');
              }
            })
            .size({ width: 24, height: 24 });

          Text('用户')
            .fontSize(16)
            .margin({ left: 8 });

          Radio({ value: 'admin', group: 'role' })
            .checked(this.role === 'admin')
            .onChange((checked: boolean) => {
              if (checked) {
                this.role = 'admin';
                console.log('选择角色: 管理员');
              }
            })
            .size({ width: 24, height: 24 })
            .margin({ left: 20 });

          Text('管理员')
            .fontSize(16)
            .margin({ left: 8 });
        }
        .margin({ bottom: 20 });

        //注册和返回按钮
        Row() {
          Button('注册')
            .width('40%')
            .height(50)
            .backgroundColor('#3498db')
            .onClick(() => {
              console.log('点击注册按钮');
              this.register();
            });

          Blank().width('10%');

          Button('返回登录')
            .width('40%')
            .height(50)
            .backgroundColor('#7f8c8d')
            .onClick(() => {
              console.log('点击返回登录按钮');
              router.pushUrl({
                url: 'pages/Login'
              });
            });
        }
        .margin({ bottom: 20 })
        .justifyContent(FlexAlign.SpaceBetween)
        .width('80%');
      }
      .width('100%')
      .height('100%')
      .padding(20)
      .justifyContent(FlexAlign.Center);
    }
    .width('100%')
    .height('100%');
  }
}
```

### 3. Management Page

#### 3.1 截图展示

管理员登录成功后可进入的页面，具备“查询”按钮，点击返回整个注册数据库的信息，用列表的方式显示，可进行解密显示明文，有分页功能可以进行上一页下一页的切换，有搜索功能，可以通过用户名、邮箱、手机号搜索
![alt text](Management.png){width=160px height=300px} ![alt text](query.png){width=160px height=300px} ![alt text](display.png){width=160px height=300px} ![alt text](decrypt.png){width=160px height=300px} ![alt text](next.png){width=160px height=300px} ![alt text](last.png){width=160px height=300px} ![alt text](search.png){width=160px height=300px}

日志输出：
![alt text](Managementlog.png){width=600px height=300px} 
![alt text](Managementlog2.png){width=600px height=300px} 
![alt text](Managementlog3.png){width=600px height=150px} 

#### 3.2 用例图与类图

![alt text](Managementusage.png){width=600px height=300px} 
![alt text](Managementclass.png){width=600px height=300px}

#### 3.3 代码实现

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
import { router } from '@kit.ArkUI'; // 引入路由模块
import { RdbManager } from '../database/RDBManager'; // 引入数据库管理类
import { User } from '../model/User'; // 引入用户模型

// 定义页面参数接口
interface PageParams {
  username?: string;
}

@Entry // 标记为入口组件
@Component // 标记为组件
struct UserListPage { // 定义用户列表页面组件
  private rdbManager = RdbManager.getInstance(); // 获取 RdbManager 单例实例
  @State users: User[] = []; // 用户列表状态
  @State currentPage: number = 1; // 当前页码状态
  @State pageSize: number = 2; // 每页数量状态
  @State totalRecords: number = 0; // 总记录数状态
  @State totalPages: number = 1; // 总页数状态
  @State isLoading: boolean = false; // 加载状态
  @State searchKeyword: string = ''; // 搜索了关键词状态
  @State hasSearched: boolean = false; // 是否已搜索状态
  @State showPassword: boolean = false; // 显示密码状态
  @State passwordMap: Map<string, boolean> = new Map(); // 密码可见性映射
  @State decryptedPasswordMap: Map<string, string> = new Map(); // 解密后的密码映射
  @State message: string = '欢迎'; // 欢迎消息状态
  private params: PageParams = {};// 页面参数

  async loadUsers() { // 加载用户列表方法
    console.log('开始加载用户列表');
    this.isLoading = true; // 设置加载状态为true
    try {
      console.log('从数据库获取所有用户');
      const allUsers = await this.rdbManager.getAllUsers(); // 从数据库获取所有用户

      console.log('根据搜索关键词过滤用户');
      this.users = allUsers.filter(user => // 根据搜索关键词过滤用户
      user.username.includes(this.searchKeyword) ||
      user.phone.includes(this.searchKeyword) ||
      user.email.includes(this.searchKeyword) ||
      user.role.includes(this.searchKeyword)
      );

      this.totalRecords = this.users.length; // 更新总记录数
      this.totalPages = Math.ceil(this.totalRecords / this.pageSize); // 更新总页数
      this.currentPage = this.currentPage > this.totalPages ? 1 : this.currentPage; // 更新当前页码
      console.log(`用户列表加载完成，共 ${this.totalRecords} 条记录`);
    } catch (error) {
      console.error('获取用户列表失败:', error);
      this.users = []; // 清空用户列表
    } finally {
      this.isLoading = false; // 重置加载状态为false
      console.log('用户列表加载流程结束');
    }
  }

  private handleSearch() { // 处理搜索请求方法
    console.log('开始处理搜索请求');
    this.hasSearched = true; // 设置已搜索状态为true
    this.currentPage = 1; // 重置当前页码为1
    this.loadUsers(); // 加载用户列表
  }

  private searchAll() { // 查询所有用户方法
    console.log('开始查询所有用户');
    this.searchKeyword = ''; // 清空搜索关键词
    this.handleSearch(); // 处理搜索请求
  }

  private getCurrentPageData(): User[] { // 获取当前页数据方法
    console.log(`获取第 ${this.currentPage} 页的数据`);
    const start = (this.currentPage - 1) * this.pageSize; // 计算起始索引
    const end = start + this.pageSize; // 计算结束索引
    return this.users.slice(start, end); // 返回当前页数据
  }

  private previousPage() { // 上一页方法
    console.log('点击上一页按钮');
    if (this.currentPage > 1) { // 如果当前页码大于1
      this.currentPage--; // 页码减1
      this.loadUsers(); // 加载用户列表
    }
  }

  private nextPage() { // 下一页方法
    console.log('点击下一页按钮');
    if (this.currentPage < this.totalPages) { // 如果当前页码小于总页数
      this.currentPage++; // 页码加1
      this.loadUsers(); // 加载用户列表
    }
  }

  private togglePasswordVisibility(userId: string) { // 切换密码可见性方法
    console.log(`切换用户 ${userId} 的密码可见性`);
    this.passwordMap.set(userId, !this.passwordMap.get(userId)); // 切换密码可见性
  }

  private async decryptPassword(user: User) { // 解密密码方法
    console.log(`开始解密用户 ${user.username} 的密码`);
    if (user.role === 'user') { // 如果用户角色是用户
      let keyData = new Uint8Array([83, 217, 231, 76, 28, 113, 23, 219, 250, 71, 209, 210, 205, 97, 32, 159]); // 定义密钥数据
      let symKey = await this.rdbManager.genSymKeyByData(keyData); // 生成对称密钥
      let decryptedPassword = await this.rdbManager.decryptMessagePromise(symKey, user.password); // 解密密码
      this.decryptedPasswordMap.set(user.username, decryptedPassword); // 存储解密后的密码
      console.log(`用户 ${user.username} 的密码解密成功`);
    } else if (user.role === 'admin') { // 如果用户角色是管理员
      let adminPriKey = await this.rdbManager.getAdminPriKey(); // 获取管理员私钥
      let decryptedPassword = await this.rdbManager.decryptMessagePromiseRSA(adminPriKey, user.password); // 解密密码
      this.decryptedPasswordMap.set(user.username, decryptedPassword); // 存储解密后的密码
      console.log(`用户 ${user.username} 的密码解密成功`);
    }
  }

  private handleMessageParams() { // 处理页面参数方法
    console.log('处理页面参数');
    if (this.params.username) { // 如果有用户名参数
      this.message = `你好, ${this.params.username}`; // 设置欢迎消息
    } else {
      this.message = '现在是游客模式'; // 设置欢迎消息为游客模式
    }
  }

  aboutToAppear() {
    console.log('页面即将显示');
    this.params = router.getParams() as PageParams ?? {}; // 获取页面参数
    this.handleMessageParams(); // 处理页面参数
    this.loadUsers(); // 加载用户列表
  }

  build() {
    Column() {
      Row() {
        //显示欢迎信息
        Text(this.message)
          .fontSize(24)
          .fontWeight(FontWeight.Bold)
          .fontColor('#3498db')
          .width('100%')
          .textAlign(TextAlign.Center)
      }
      .width('100%')
      .margin({ top: 10, bottom: 10 })
      .padding(15)
      .backgroundColor('#ffffff')
      .borderRadius(10)
      .shadow({
        radius: 2,
        color: '#f0f0f0',
        offsetX: 0,
        offsetY: 1
      })

      Row() {
        //返回按钮
        Button() {
          Row({ space: 5 }) {
            Image($r('app.media.back'))
              .width(20)
              .height(20)
            Text('返回')
              .fontSize(14)
          }
        }
        .width(80)
        .height(40)
        .borderRadius(20)
        .backgroundColor('#f5f5f5')
        .onClick(() => {
          console.log('点击返回按钮');
          router.back();
        })

        //搜索框查询
        TextInput({ placeholder: '输入用户名/电话/邮箱', text: this.searchKeyword })
          .layoutWeight(1)
          .height(40)
          .margin({ left: 10, right: 10 })
          .padding(8)
          .borderRadius(20)
          .backgroundColor(Color.White)
          .onChange((value: string) => {
            this.searchKeyword = value;
          })

        //搜索按钮
        Button('搜索')
          .width(80)
          .height(40)
          .backgroundColor('#3498db')
          .fontColor(Color.White)
          .borderRadius(20)
          .onClick(() => {
            console.log('点击搜索按钮');
            this.handleSearch();
          })
      }
      .width('100%')
      .padding(15)
      .backgroundColor('#ffffff')
      .borderRadius(10)
      .shadow({
        radius: 2,
        color: '#f0f0f0',
        offsetX: 0,
        offsetY: 1
      })

      //查询所有信息按钮
      if (!this.hasSearched) {
        Button('查询所有信息')
          .width('60%')
          .height(50)
          .margin(20)
          .backgroundColor('#3498db')
          .fontColor(Color.White)
          .fontSize(18)
          .borderRadius(25)
          .onClick(() => {
            console.log('点击查询所有信息按钮');
            this.searchAll();
          })
      }

      if (this.hasSearched) {
        if (this.isLoading) {
          Column() {
            LoadingProgress()
              .width(50)
              .height(50)
            Text('加载中...')
              .margin({ top: 10 })
              .fontSize(14)
              .fontColor('#999')
          }
          .width('100%')
          .height('100%')
          .justifyContent(FlexAlign.Center)
          .alignItems(HorizontalAlign.Center)
        } else if (this.users.length === 0) {
          Column() {
            Image($r('app.media.empty'))
              .width(100)
              .height(100)
            Text('暂无已注册列表')
              .margin({ top: 15 })
              .fontSize(16)
              .fontColor('#999')
          }
          .width('100%')
          .height('100%')
          .justifyContent(FlexAlign.Center)
          .alignItems(HorizontalAlign.Center)
        } else {
          //用列表的方式显示整个注册数据库的信息
          List({ space: 15 }) {
            ForEach(this.getCurrentPageData(), (user: User) => {
              ListItem() {
                Column() {
                  Row() {
                    Image($r('app.media.mainuser'))
                      .width(20)
                      .height(20)
                      .margin({ right: 8 })
                    Text(`用户名: ${user.username}`)
                      .fontSize(16)
                      .fontWeight(FontWeight.Medium)
                      .layoutWeight(1)
                      .maxLines(1)
                      .textOverflow({ overflow: TextOverflow.Ellipsis })
                  }
                  .width('100%')
                  .margin({ bottom: 8 })

                  Row() {
                    Image($r('app.media.key'))
                      .width(16)
                      .height(16)
                      .margin({ right: 8 })
                    Text(`密码: ${this.passwordMap.get(user.username) ? user.password : '******'}`)
                      .fontSize(14)
                      .fontColor('#666')
                  }
                  .width('100%')
                  .margin({ bottom: 8 })

                  Row() {
                    Image($r('app.media.role'))
                      .width(16)
                      .height(16)
                      .margin({ right: 8 })
                    Text(`身份: ${user.role}`)
                      .fontSize(14)
                      .fontColor('#666')
                  }
                  .width('100%')
                  .margin({ bottom: 8 })

                  Row() {
                    Image($r('app.media.sex'))
                      .width(16)
                      .height(16)
                      .margin({ right: 8 })
                    Text(`性别: ${user.sex}`)
                      .fontSize(14)
                      .fontColor('#666')
                  }
                  .width('100%')
                  .margin({ bottom: 8 })

                  Row() {
                    Image($r('app.media.phone'))
                      .width(16)
                      .height(16)
                      .margin({ right: 8 })
                    Text(`电话: ${user.phone}`)
                      .fontSize(14)
                      .fontColor('#666')
                  }
                  .width('100%')
                  .margin({ bottom: 8 })

                  Row() {
                    Image($r('app.media.email'))
                      .width(16)
                      .height(16)
                      .margin({ right: 8 })
                    Text(`邮箱: ${user.email}`)
                      .fontSize(14)
                      .fontColor('#999')
                  }
                  .width('100%')

                  //显示存储在数据库中的密码
                  Button('显示密码')
                    .width(100)
                    .height(30)
                    .margin({ top: 10 })
                    .backgroundColor('#3498db')
                    .fontColor(Color.White)
                    .fontSize(12)
                    .borderRadius(15)
                    .onClick(() => {
                      console.log(`点击显示密码按钮，用户: ${user.username}`);
                      this.togglePasswordVisibility(user.username);
                    })

                  //解密为注册时的明文密码
                  Button('解密密码')
                    .width(100)
                    .height(30)
                    .margin({ top: 10 })
                    .backgroundColor('#27ae60')
                    .fontColor(Color.White)
                    .fontSize(12)
                    .borderRadius(15)
                    .onClick(async () => {
                      console.log(`点击解密密码按钮，用户: ${user.username}`);
                      await this.decryptPassword(user);
                    })

                  if (this.decryptedPasswordMap.get(user.username)) {
                    Text(`解密后的密码: ${this.decryptedPasswordMap.get(user.username)}`)
                      .fontSize(14)
                      .fontColor('#27ae60')
                      .margin({ top: 5 })
                  }
                }
                .padding(15)
                .backgroundColor('#ffffff')
                .borderRadius(8)
                .shadow({
                  radius: 2,
                  color: '#f0f0f0',
                  offsetX: 0,
                  offsetY: 1
                })
              }
              .margin({
                left: 15,
                right: 15,
                top: 5,
                bottom: 5
              })
            })
          }
          .width('100%')
          .layoutWeight(1)
          .backgroundColor('#f9f9f9')
        }

        Row() {
          //上一页按钮
          Button('上一页')
            .onClick(() => {
              console.log('点击上一页按钮');
              this.previousPage();
            })
            .enabled(this.currentPage > 1)
            .backgroundColor('#3498db')

          Text(`${this.currentPage}/${this.totalPages}`)
            .fontSize(16)
            .margin({ left: 20, right: 20 })

          //下一页按钮
          Button('下一页')
            .onClick(() => {
              console.log('点击下一页按钮');
              this.nextPage();
            })
            .enabled(this.currentPage < this.totalPages)
            .backgroundColor('#3498db')
        }
        .width('100%')
        .padding(10)
        .backgroundColor(Color.White)
        .justifyContent(FlexAlign.Center)
      }
    }
    .width('100%')
      .height('100%')
      .backgroundColor('#f9f9f9');
  }
}
```

### 4. 其他页面

#### 4.1 数据库和加密

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
import { relationalStore, ValuesBucket } from '@kit.ArkData';//数据库
import { cryptoFramework } from '@kit.CryptoArchitectureKit';//加密
import { buffer } from '@kit.ArkTS';//数据缓冲
import { BusinessError } from '@kit.BasicServicesKit';//处理业务错误
import promptAction from '@ohos.promptAction';//显示提示信息
import { User } from '../model/User';

// 定义 StoreConfig 接口，用于配置数据库
interface StoreConfig {
  name: string;
  securityLevel: relationalStore.SecurityLevel;
}
// 定义 RdbError 接口，继承自 BusinessError，用于处理数据库错误
interface RdbError extends BusinessError {
  sql?: string;
  message: string;
  code: number;
}
// 导出 RdbManager 类，用于管理数据库操作
export class RdbManager {
  private static instance: RdbManager;//单例模式
  private context?: Context;//上下文
  private rdbStore: relationalStore.RdbStore | null = null;//数据库存储

  private readonly USER_TABLE = 'users';//用户表名称

  //创建用户表
  private readonly createTableSql = [
    `CREATE TABLE IF NOT EXISTS ${this.USER_TABLE} (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      sex TEXT NOT NULL CHECK (sex IN ('male', 'female')),
      phone TEXT,
      email TEXT,
      role TEXT NOT NULL CHECK (role IN ('user', 'admin'))
    )`
  ];
  // 异步方法 initRdbStore，用于初始化数据库
  async initRdbStore(context: Context): Promise<void> {
    console.log('开始初始化数据库');
    try {
      // 配置数据库
      const config: StoreConfig = {
        name: 'checkin.db',
        securityLevel: relationalStore.SecurityLevel.S3
      };
      // 获取数据库实例
      this.rdbStore = await relationalStore.getRdbStore(context, config);

      // 执行建表 SQL 语句
      for (const sql of this.createTableSql) {
        try {
          await this.rdbStore.executeSql(sql);
          console.log(`执行SQL成功: ${sql.substring(0, 50)}...`); // 截取部分SQL日志
        } catch (sqlError) {
          console.error(`执行SQL失败: ${sql} | CODE: ${sqlError.code}, MESSAGE: ${sqlError.message}`);
        }
      }
      console.log('数据库初始化成功');
    } catch (error) {
      console.error('数据库初始化失败:', error);
    }
  }
  // 静态方法 getInstance，用于获取 RdbManager 实例
  public static getInstance(context?: Context): RdbManager {
    if (!RdbManager.instance) {
      RdbManager.instance = new RdbManager();
      if (context) {
        RdbManager.instance.context = context;
      }
    }
    return RdbManager.instance;
  }
  // 异步方法 encryptData，用于加密数据
  async encryptData(data: string, role: 'user' | 'admin'): Promise<string> {
    console.log(`开始加密数据，角色: ${role}`);
    if (role === 'user') {
      // 定义对称密钥数据
      let keyData = new Uint8Array([83, 217, 231, 76, 28, 113, 23, 219, 250, 71, 209, 210, 205, 97, 32, 159]);
      // 生成对称密钥
      let symKey = await this.genSymKeyByData(keyData);
      // 定义明文数据
      let plainText: cryptoFramework.DataBlob = { data: new Uint8Array(buffer.from(data, 'utf-8').buffer) };
      console.log('数据加密完成');
      // 返回加密后的数据
      return await this.encryptMessagePromise(symKey, plainText); // 直接返回拼接后的Base64
    } else if (role === 'admin') {
      // 获取管理员公钥
      let adminPubKey = await this.getAdminPubKey();
      // 定义明文数据
      let plainText: cryptoFramework.DataBlob = { data: new Uint8Array(buffer.from(data, 'utf-8').buffer) };
      console.log('数据加密完成');
      // 返回加密后的数据
      return await this.encryptMessagePromiseRSA(adminPubKey, plainText);
    } else {
      return data;
    }
  }
  // 异步方法 decryptData，用于解密数据
  async decryptData(encryptedData: string, role: 'user' | 'admin'): Promise<string> {
    console.log(`开始解密数据，角色: ${role}`);
    // 定义对称密钥数据
    if (role === 'user') {
      let keyData = new Uint8Array([83, 217, 231, 76, 28, 113, 23, 219, 250, 71, 209, 210, 205, 97, 32, 159]);
      // 生成对称密钥
      let symKey = await this.genSymKeyByData(keyData);
      console.log('数据解密完成');
      // 返回解密后的数据
      return await this.decryptMessagePromise(symKey, encryptedData); // 传入Base64字符串
    }else if (role === 'admin') {
      // 获取管理员私钥
      let adminPriKey = await this.getAdminPriKey();
      console.log('数据解密完成');
      // 返回解密后的数据
      return await this.decryptMessagePromiseRSA(adminPriKey, encryptedData);
    }  else {
      return encryptedData;
    }
  }
  // 异步方法 encryptMessagePromiseRSA，用于使用 RSA 公钥加密消息
  async encryptMessagePromiseRSA(publicKey: cryptoFramework.PubKey, plainText: cryptoFramework.DataBlob) {
    // 创建加密器
    let cipher = cryptoFramework.createCipher('RSA1024|PKCS1');
    // 初始化加密器
    await cipher.init(cryptoFramework.CryptoMode.ENCRYPT_MODE, publicKey, null);
    // 执行加密
    let encryptData = await cipher.doFinal(plainText);
    // 返回加密后的数据，转换为 Base64 编码
    return buffer.from(encryptData.data).toString('base64');
  }
  // 异步方法 decryptMessagePromiseRSA，用于使用 RSA 私钥解密消息
  async decryptMessagePromiseRSA(privateKey: cryptoFramework.PriKey, cipherTextBase64: string): Promise<string> {
    // 将 Base64 编码的密文转换为字节数组
    let cipherText = new Uint8Array(buffer.from(cipherTextBase64, 'base64').buffer);
    // 创建加密器
    let cipher = cryptoFramework.createCipher('RSA1024|PKCS1');
    // 初始化加密器
    await cipher.init(cryptoFramework.CryptoMode.DECRYPT_MODE, privateKey, null);
    // 执行解密
    let decryptData = await cipher.doFinal({ data: cipherText });
    // 返回解密后的数据，转换为 UTF-8 编码
    return buffer.from(decryptData.data).toString('utf-8');
  }
  // 异步方法 getAdminPubKey，用于获取管理员公钥
  async getAdminPubKey(): Promise<cryptoFramework.PubKey> {
    // 定义公钥数据
    let pkData = new Uint8Array([
      48, 129, 159, 48, 13, 6, 9, 42, 134, 72, 134, 247, 13, 1, 1, 1, 5, 0, 3, 129, 141, 0, 48, 129, 137, 2, 129, 129, 0, 197, 64, 10, 198, 14, 110, 65, 92, 206, 35, 28, 123, 153, 24, 134, 255, 145, 74, 42, 173, 40, 215, 146, 58, 143, 46, 10, 195, 154, 160, 69, 196, 220, 152, 179, 44, 111, 200, 84, 78, 215, 73, 210, 181, 12, 29, 70, 68, 36, 135, 153, 89, 230, 202, 130, 212, 111, 243, 234, 92, 131, 62, 145, 50, 73, 48, 104, 245, 46, 70, 45, 157, 147, 143, 140, 162, 156, 216, 220, 49, 121, 142, 194, 33, 223, 201, 0, 16, 163, 210, 240, 118, 92, 147, 121, 220, 17, 114, 24, 52, 125, 135, 176, 88, 21, 83, 86, 17, 156, 88, 250, 48, 79, 86, 128, 248, 105, 208, 133, 140, 13, 153, 164, 191, 136, 164, 44, 53, 2, 3, 1, 0, 1
    ]);
    // 定义公钥数据Blob
    let pubKeyBlob: cryptoFramework.DataBlob = { data: pkData };
    // 创建非对称密钥生成器
    let rsaGenerator = cryptoFramework.createAsyKeyGenerator('RSA1024');
    // 转换公钥
    let keyPair = await rsaGenerator.convertKey(pubKeyBlob, null); // 只转换公钥
    console.info('管理员公钥转换成功');
    // 返回公钥
    return keyPair.pubKey;
  }
  // 异步方法 getAdminPriKey，用于获取管理员私钥
  async getAdminPriKey(): Promise<cryptoFramework.PriKey> {
    // 定义私钥数据
    let skData = new Uint8Array([
      48, 130, 2, 119, 2, 1, 0, 48, 13, 6, 9, 42, 134, 72, 134, 247, 13, 1, 1, 1, 5, 0, 4, 130, 2, 97, 48, 130, 2, 93, 2, 1, 0, 2, 129, 129, 0, 197, 64, 10, 198, 14, 110, 65, 92, 206, 35, 28, 123, 153, 24, 134, 255, 145, 74, 42, 173, 40, 215, 146, 58, 143, 46, 10, 195, 154, 160, 69, 196, 220, 152, 179, 44, 111, 200, 84, 78, 215, 73, 210, 181, 12, 29, 70, 68, 36, 135, 153, 89, 230, 202, 130, 212, 111, 243, 234, 92, 131, 62, 145, 50, 73, 48, 104, 245, 46, 70, 45, 157, 147, 143, 140, 162, 156, 216, 220, 49, 121, 142, 194, 33, 223, 201, 0, 16, 163, 210, 240, 118, 92, 147, 121, 220, 17, 114, 24, 52, 125, 135, 176, 88, 21, 83, 86, 17, 156, 88, 250, 48, 79, 86, 128, 248, 105, 208, 133, 140, 13, 153, 164, 191, 136, 164, 44, 53, 2, 3, 1, 0, 1, 2, 129, 128, 70, 75, 184, 139, 53, 1, 94, 17, 240, 244, 218, 101, 193, 253, 215, 190, 164, 204, 197, 192, 200, 89, 107, 39, 171, 119, 65, 38, 204, 168, 105, 180, 234, 217, 16, 161, 185, 132, 175, 103, 25, 154, 153, 153, 36, 36, 26, 178, 150, 66, 45, 8, 185, 19, 90, 228, 210, 177, 30, 200, 177, 141, 78, 184, 248, 59, 113, 154, 145, 73, 160, 24, 73, 157, 86, 207, 186, 32, 95, 200, 106, 252, 107, 69, 170, 193, 216, 196, 181, 142, 74, 203, 15, 18, 89, 228, 152, 19, 239, 21, 233, 98, 121, 214, 57, 187, 111, 239, 223, 248, 199, 70, 223, 108, 108, 113, 234, 144, 155, 95, 246, 144, 244, 122, 39, 55, 127, 81, 2, 65, 0, 246, 96, 188, 0, 0, 104, 221, 105, 139, 144, 63, 175, 209, 87, 179, 162, 88, 192, 99, 82, 125, 53, 54, 48, 70, 245, 239, 37, 15, 242, 247, 84, 115, 187, 196, 95, 156, 40, 165, 60, 64, 102, 13, 229, 243, 2, 149, 0, 232, 226, 221, 192, 95, 11, 12, 208, 5, 181, 98, 62, 210, 190, 141, 235, 2, 65, 0, 204, 244, 34, 10, 105, 80, 76, 116, 163, 35, 231, 168, 187, 206, 189, 101, 215, 103, 80, 115, 86, 11, 34, 127, 203, 114, 84, 188, 121, 174, 169, 31, 142, 2, 182, 27, 140, 225, 157, 227, 71, 98, 15, 203, 187, 213, 5, 190, 20, 121, 8, 30, 193, 100, 232, 101, 141, 8, 124, 20, 29, 78, 6, 95, 2, 65, 0, 204, 43, 225, 224, 6, 118, 224, 117, 100, 200, 199, 94, 70, 23, 109, 175, 173, 232, 208, 230, 61, 8, 105, 189, 156, 48, 150, 91, 154, 89, 248, 136, 173, 215, 254, 166, 84, 220, 130, 1, 234, 68, 40, 100, 84, 251, 224, 202, 254, 51, 115, 28, 198, 38, 124, 25, 175, 129, 94, 199, 61, 17, 216, 189, 2, 64, 72, 230, 129, 129, 48, 138, 134, 87, 106, 123, 231, 247, 165, 173, 216, 194, 115, 198, 228, 223, 209, 120, 46, 114, 68, 92, 75, 117, 170, 214, 140, 131, 147, 208, 181, 19, 193, 157, 178, 186, 87, 246, 178, 101, 166, 79, 20, 54, 211, 51, 101, 199, 2, 197, 48, 192, 134, 84, 193, 69, 170, 82, 201, 131, 2, 65, 0, 213, 165, 55, 166, 131, 210, 195, 56, 250, 147, 195, 61, 205, 208, 189, 185, 40, 52, 50, 119, 137, 23, 246, 46, 220, 108, 52, 23, 152, 154, 94, 32, 144, 195, 184, 249, 21, 168, 12, 57, 222, 18, 60, 117, 81, 157, 72, 30, 155, 190, 165, 242, 228, 139, 240, 184, 145, 170, 103, 210, 160, 161, 135, 13
    ]);
    // 定义私钥数据Blob
    let priKeyBlob: cryptoFramework.DataBlob = { data: skData };
    // 创建非对称密钥生成器
    let rsaGenerator = cryptoFramework.createAsyKeyGenerator('RSA1024');
    //转换私钥
    let keyPair = await rsaGenerator.convertKey(null, priKeyBlob); // 只转换私钥
    console.info('管理员公钥转换成功');
    //返回私钥
    return keyPair.priKey;
  }

  // 方法 genGcmParamsSpec，用于生成 GCM 参数规范
  genGcmParamsSpec(iv?: Uint8Array): cryptoFramework.GcmParamsSpec {
    // 如果传入 iv，则使用它（解密时）；否则生成随机 iv（加密时）
    const ivBlob = iv || this.generateRandom(12);

    // 固定 AAD（
    const aad = new Uint8Array([1, 2, 3, 4, 5, 6, 7, 8]); // 8 字节

    // 初始化 authTag（解密时会覆盖）
    const authTag = new Uint8Array(16); // 16 字节占位

    return {
      iv: { data: ivBlob },
      aad: { data: aad }, // 固定 AAD
      authTag: { data: authTag },
      algName: "GcmParamsSpec"
    };
  }
  // 异步方法 encryptMessagePromise，用于加密消息
  async encryptMessagePromise(symKey: cryptoFramework.SymKey, plainText: cryptoFramework.DataBlob) {
    // 生成加密参数（包含随机 IV 和固定 AAD）
    const gcmParams = this.genGcmParamsSpec();
    //创建加密器
    const cipher = cryptoFramework.createCipher('AES128|GCM|PKCS7');
    //初始化加密器
    await cipher.init(cryptoFramework.CryptoMode.ENCRYPT_MODE, symKey, gcmParams);
    //执行加密更新
    const encryptUpdate = await cipher.update(plainText);
    //执行加密最终化
    const encryptFinal = await cipher.doFinal(null); // 获取最终的加密数据和 authTag

    // 从 doFinal 结果中获取真实的 authTag
    const authTag = encryptFinal.data;

    // 拼接 IV + 加密数据 + authTag
    const combined = new Uint8Array([
      ...gcmParams.iv.data,
      ...encryptUpdate.data,
      ...authTag
    ]);
    // 返回加密后的数据，转换为 Base64 编码
    return buffer.from(combined).toString('base64');
  }
  // 异步方法 decryptMessagePromise，用于解密消息
  async decryptMessagePromise(symKey: cryptoFramework.SymKey, cipherTextBase64: string): Promise<string> {
    // 将 Base64 编码的密文转换为字节数组
    const combined = new Uint8Array(buffer.from(cipherTextBase64, 'base64').buffer);

    // 分割各部分（IV: 12字节, 加密数据: 中间部分, authTag: 最后16字节）
    const iv = combined.subarray(0, 12);
    const encryptedData = combined.subarray(12, combined.length - 16);
    const authTag = combined.subarray(combined.length - 16);

    // 使用相同的 AAD 构造解密参数
    const gcmParams = this.genGcmParamsSpec(iv);
    gcmParams.authTag.data = authTag; // 覆盖为真实 authTag
    // 创建加密器
    const decoder = cryptoFramework.createCipher('AES128|GCM|PKCS7');
    // 初始化加密器
    await decoder.init(cryptoFramework.CryptoMode.DECRYPT_MODE, symKey, gcmParams);
    // 执行解密更新
    const decryptUpdate = await decoder.update({ data: encryptedData });
    //执行解密最终化
    const decryptFinal = await decoder.doFinal(null);

    // 合并解密结果
    const decryptedBytes = new Uint8Array([
      ...decryptUpdate.data,
      ...(decryptFinal?.data || [])
    ]);
    // 返回解密后的数据，转换为 UTF-8 编码
    return buffer.from(decryptedBytes.buffer).toString('utf-8');
  }
  // 异步方法 genSymKeyByData，用于从数据生成对称密钥
  async genSymKeyByData(symKeyData: Uint8Array) {
    // 定义密钥数据Blob
    let symKeyBlob: cryptoFramework.DataBlob = { data: symKeyData };
    // 创建对称密钥生成器
    let aesGenerator = cryptoFramework.createSymKeyGenerator('AES128');
    //转换密钥
    let symKey = await aesGenerator.convertKey(symKeyBlob);
    console.info('密钥转换成功');
    //返回对称密钥
    return symKey;
  }
  // 方法 generateRandom，用于生成随机字节数组
  generateRandom(len: number): Uint8Array {
    // 创建随机字节数组
    let randomBytes = new Uint8Array(len);
    // 填充随机字节
    for (let i = 0; i < len; i++) {
      randomBytes[i] = Math.floor(Math.random() * 256);
    }
    // 返回随机字节数组
    return randomBytes;
  }
  // 异步方法 registerUser，用于注册用户
  async registerUser(
    username: string,
    password: string,
    sex: 'male' | 'female',
    phone: string,
    email: string,
    role: 'user' | 'admin'
  ): Promise<boolean> {
    console.log(`开始注册用户: ${username}, 角色: ${role}`);
    if (!this.rdbStore) {
      console.error('数据库未初始化');
      return false;
    }

    try {
      // 检查用户名是否已被占用
      const isTaken = await this.isUsernameTaken(username);
      if (isTaken) {
        promptAction.showToast({ message: '用户名已存在', duration: 2000 });
        return false;
      }

      // 加密密码
      const encryptedPassword = await this.encryptData(password, role);

      // 使用 insert 方法插入数据
      const valueBucket: ValuesBucket = {
        'username': username,
        'password': encryptedPassword,
        'sex': sex,
        'phone': phone,
        'email': email,
        'role': role
      };
      // 插入数据到数据库
      const rowId = await this.rdbStore.insert(this.USER_TABLE, valueBucket);
      console.log(`用户 ${username} 注册成功`);
      return rowId > 0;
    } catch (error) {
      const err = error as RdbError;
      console.error(
        `注册失败: CODE=${err.code}, MESSAGE=${err.message}\n` +
          `SQL=${err.sql ?? '未知'}\n参数: ${JSON.stringify([username,password, phone, sex, email, role])}`
      );
      promptAction.showToast({ message: '注册失败，请检查数据格式', duration: 2000 });
      return false;
    }
  }
  // 异步方法 loginUser，用于验证用户登录
  async loginUser(username: string, password: string, role: 'user' | 'admin'): Promise<boolean> {
    console.log(`开始验证用户登录: ${username}, 角色: ${role}`);
    if (!this.rdbStore) {
      console.error('数据库未初始化');
      return false;
    }
    // 定义结果集
    let resultSet: relationalStore.ResultSet | null = null;
    try {
      // 定义查询条件
      const predicates = new relationalStore.RdbPredicates(this.USER_TABLE);
      predicates.equalTo('username', username);
      predicates.equalTo('role', role);

      resultSet = await this.rdbStore.query(predicates, ['password']);
      if (resultSet.rowCount === 0) {
        return false;
      }
      // 执行查询
      const isAtFirstRow = await resultSet.goToFirstRow();
      if (!isAtFirstRow) {
        return false;
      }
      // 移动到第一行
      const row = resultSet.getRow();
      const encryptedPassword = String(row['password']);
      const decryptedPassword = await this.decryptData(encryptedPassword, role);
      console.log(`用户 ${username} 登录成功`);
      // 验证密码是否匹配
      return decryptedPassword === password;

    } catch (error) {
      console.error('用户登录失败:', error);
      return false;
    } finally {
      // 关闭结果集
      resultSet?.close();
    }
  }
  // 异步方法 isUsernameTaken，用于检查用户名是否已被占用
  async isUsernameTaken(username: string): Promise<boolean> {
    console.log(`检查用户名是否已被占用: ${username}`);
    if (!this.rdbStore) {
      console.error('数据库未初始化');
      return false;
    }
    // 定义结果集
    let resultSet: relationalStore.ResultSet | null = null;
    try {
      // 定义查询条件
      const predicates = new relationalStore.RdbPredicates(this.USER_TABLE);
      predicates.equalTo('username', username);
      // 执行查询
      resultSet = await this.rdbStore.query(predicates, ['id']);
      console.log(`用户名 ${username} 可用'}`);
      return resultSet.rowCount > 0;
    } catch (error) {
      console.error('查找用户名失败:', error);
      return false;
    } finally {
      // 关闭结果集
      resultSet?.close();
    }
  }
  // 异步方法 getAllUsers，用于获取所有用户
  async getAllUsers(): Promise<User[]> {
    console.log('开始获取所有用户信息');
    if (!this.rdbStore && this.context) {
      await this.initRdbStore(this.context);
    } else if (!this.rdbStore) {
      console.error("未获得上下文且数据库未初始化");
      return [];
    }
    // 定义用户数组
    const users: User[] = [];
    // 定义结果集
    let resultSet: relationalStore.ResultSet | null = null;

    try {
      // 定义查询条件
      const predicates = new relationalStore.RdbPredicates(this.USER_TABLE);
      // 执行查询
      resultSet = await this.rdbStore!.query(
        predicates,
        ['username','password','sex','phone', 'email','role']
      );

      if (resultSet.rowCount === 0) {
        console.log("没有注册用户");
        return [];
      }
      // 移动到第一行
      const isAtFirstRow = await resultSet.goToFirstRow();
      if (!isAtFirstRow) {
        console.log("无法移动到第一行");
        return [];
      }
      // 遍历结果集
      do {
        const row = resultSet.getRow();
        users.push({
          username: String(row['username']),
          password: String(row['password']),
          phone: String(row['phone']),
          sex: String(row['sex']) as 'male' | 'female',
          email: String(row['email']),
          role: String(row['role']) as 'user' | 'admin'
        });
      } while (await resultSet.goToNextRow());

    } catch (err) {
      console.error(`查询用户失败: Code=${err.code}, Message=${err.message}`);
    } finally {
      // 关闭结果集
      resultSet?.close();
    }
    console.log(`获取到 ${users.length} 个用户`);
    // 返回用户数组
    return users;
  }
  // 异步方法 debugTableInfo，用于调试表信息
  async debugTableInfo(): Promise<void> {
    console.log('开始查询数据库表信息');
    if (!this.rdbStore) return;
    const sql = `PRAGMA table_info(${this.USER_TABLE})`;
    const resultSet = await this.rdbStore.executeSql(sql);
    // 输出字段名、类型、是否非空等信息
    console.log('数据库表信息查询完成');
  }
}
```

#### 4.2 用户类

<在此处填写你的代码实现（带必要注释及Markdown语法高亮）>

插入代码的语法示例：
```typescript {.line-numbers}
export interface User {
  username: string;
  password: string;
  sex : 'male' | 'female'
  phone: string;
  email: string;
  role: 'user' | 'admin';
}

```
