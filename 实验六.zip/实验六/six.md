# 实验六报告

> 学号：<3225706015>
> 
> 姓名：<郭佳欣>
> 
> 指导老师：<张凯斌>
> 
> 实验日期：<2025-04-25>

## 一、实验目的

- 完成实验五中的L/R页面功能；
- 锻炼课堂所讲授的面向对象分析与设计能力；
- 实践编码能力

## 二、实验内容

- 依托教科书的第9章“数据管理”；
- 回顾实验三与实验四内容；
- 结合《课程指导》

完成本次实验。

## 三、实验要求

- Login/Registration System
  - 本次实验要求完成完整的登录/注册功能
- 基本需求
  - 三个UI Pages
    - L/R Page（实验五已进行）
      - 添加一个“角色”选项
        - 用户
        - 管理员
      - 输对用户名和密码后
        - 用户进入Home Page
        - 管理员进入Management Page
      - 如果登录信息不存在，提示进行“注册”
      - 连续3次输错密码后，关闭整个App
    - Registration Page
      - 引导用户输入注册信息
        - 用户名、性别、邮箱、密码、角色为必选项，其他自行设计
        - 需对用户输入内容进行形式判断，如数据类型等
          - 形式判断错误的，需要引导用户重新输入
      - 点击确认按钮后信息存入SQLite数据库
        - “用户”采用HarmonyOS的built-in加密存储功能
        - “管理员”采用自行加密模块处理后存储
    - Management Page
      - 此为管理员登录成功后可进入的页面
      - 具备“查询”按钮，点击返回整个注册数据库的信息
        - 跳转页面后用列表显示出来
          - 需解密后显示明文
  - 完成用例图和详细类图
    - 其他类型的图不要求
  - 完成编码实现
- 技术要求
  - 不能使用回调函数来完成异步编程，全部使用async/await形式
  - 必须有关键节点的日志输出



## 四、实验步骤

### 1. L/R Page

#### 1.1 截图展示

<img
src=1.png>
<img
src=7.png>

#### 1.2 用例图与类图
<img src=类1.png>
<img src=用例1.png>

#### 1.3 代码实现

```typescript {.line-numbers}
import router from '@ohos.router';
import { BusinessError } from '@ohos.base';
import promptAction from '@ohos.promptAction';
import app from '@ohos.app.ability.common';
import { relationalStoreDB } from '../model/RelationalDatabase';
import { appContext } from '../model/AppContext';

@Entry
@Component
struct LoginPage {
  @State username: string = ''
  @State password: string = ''
  @State role: string = 'user'
  @State errorMessage: string = ''
  @State loginLoading: boolean = false
  private context: app.UIAbilityContext = getContext(this) as app.UIAbilityContext;

  aboutToAppear() {
    // 初始化数据库
    const context = getContext(this) as app.Context;
    appContext.initDatabase(context);
  }

  // 处理登录
  async handleLogin() {
    if (!this.username || !this.password) {
      this.errorMessage = '请输入用户名和密码';
      return;
    }

    this.loginLoading = true;
    this.errorMessage = '';

    try {
      // 验证登录
      const loginSuccess = await new Promise<boolean>((resolve) => {
        relationalStoreDB.verifyLogin(
          this.username as string,
          this.password as string,
          this.role as string,
          (success: boolean) => {
            resolve(success);
          }
        );
      });

      if (loginSuccess) {
        // 重置登录失败计数
        relationalStoreDB.resetLoginFailure(this.username);

        // 跳转到首页
        await router.pushUrl({
          url: 'pages/HomePage'
        });
      } else {
        // 记录登录失败
        const failCount = relationalStoreDB.recordLoginFailure(this.username);

        if (failCount >= 3) {
          AlertDialog.show({
            title: '登录失败',
            message: '连续3次密码错误，应用将自动关闭',
            autoCancel: false,
            alignment: DialogAlignment.Center,
            primaryButton: {
              value: '确定',
              action: () => {
                // 退出应用
                this.context.terminateSelf();
              }
            }
          });
        } else {
          // 检查用户是否存在
          const userExists = await new Promise<boolean>((resolve) => {
            relationalStoreDB.checkUserExists(this.username as string, (exists: boolean) => {
              resolve(exists);
            });
          });

          if (!userExists) {
            this.errorMessage = '用户不存在，请先注册';
          } else {
            this.errorMessage = `用户名或密码错误，还剩${3 - failCount}次机会`;
          }
        }
      }
    } catch (error) {
      console.error(`登录失败: ${error instanceof Error ? error.message : JSON.stringify(error)}`);
      this.errorMessage = '登录过程中发生错误，请稍后再试';
    } finally {
      this.loginLoading = false;
    }
  }

  build() {
    Column() {
      Text(this.errorMessage)
        .fontSize(14)
        .fontColor(Color.Red)
        .margin({ top: 10, bottom: 10 })
        .visibility(this.errorMessage ? Visibility.Visible : Visibility.None)

      Text('用户登录')
        .fontSize(30)
        .margin({ bottom: 40 })

      TextInput({ placeholder: '用户名' })
        .width('80%')
        .height(50)
        .margin({ bottom: 20 })
        .onChange(value => this.username = value)

      TextInput({ placeholder: '密码' })
        .width('80%')
        .height(50)
        .type(InputType.Password)
        .onChange(value => this.password = value)

      // 角色选择
      Column({ space: 10 }) {
        Text('请选择角色')
          .fontSize(16)
          .margin({ top: 20 })

        Row({ space: 20 }) {
          Radio({ value: 'user', group: 'role' })
            .checked(this.role === 'user')
            .onChange(checked => {
              if (checked) this.role = 'user'
            })
          Text('用户')
            .fontSize(16)

          Radio({ value: 'admin', group: 'role' })
            .checked(this.role === 'admin')
            .onChange(checked => {
              if (checked) this.role = 'admin'
            })
          Text('管理员')
            .fontSize(16)
        }
      }
      .width('80%')
      .alignItems(HorizontalAlign.Start)

      Button('登录')
        .width('80%')
        .height(50)
        .margin({ top: 30 })
        .enabled(!this.loginLoading)
        .onClick(() => this.handleLogin())

      Row() {
        Text('没有账号？')
          .fontSize(14)

        Text('立即注册')
          .fontSize(14)
          .fontColor(Color.Blue)
          .margin({ left: 10 })
          .onClick(async () => {
            await router.pushUrl({
              url: 'pages/RegistrationPage'
            });
          })
      }
      .margin({ top: 20 })
    }
    .width('100%')
    .height('100%')
    .padding(20)
    .justifyContent(FlexAlign.Center)
  }
}
```


### 2. Registration Page

#### 2.1 截图展示

<img
src=2.png>
<img
src=3.png>
<img
src=4.png>
<img
src=5.png>

#### 2.2 用例图与类图

<img src=类2.png>
<img src=用例2.png>

#### 2.3 代码实现

```typescript {.line-numbers}
import router from '@ohos.router';
import promptAction from '@ohos.promptAction';
import { relationalStoreDB } from '../model/RelationalDatabase';


@Entry
@Component
struct RegisterPage {
  private userDatabase = relationalStoreDB;

  @State username: string = "";
  @State gender: string = "male";
  @State email: string = "";
  @State password: string = "";
  @State confirmPassword: string = "";
  @State isProcessing: boolean = false;
  @State passwordStrength: number = 0;
  @State role: "user" | "admin" = "user";

  aboutToAppear() {
    this.userDatabase.initStoreRDB(getContext(this), 'Users');
  }

  build() {
    Column() {
      Text("用户注册")
        .fontSize(30)
        .fontWeight(FontWeight.Bold)
        .margin({ bottom: 30 })

      // 用户名输入
      TextInput({ placeholder: "请输入用户名 (3-20位)" })
        .width("90%")
        .height(50)
        .margin({ bottom: 15 })
        .onChange((value: string) => {
          this.username = value.trim();
        })

      // 性别选择
      Row() {
        Text("性别：")
          .fontSize(18)
          .margin({ right: 15 })

        Radio({ value: 'male', group: 'gender' })
          .checked(this.gender === 'male')
          .onChange((isChecked: boolean) => {
            if (isChecked) this.gender = 'male';
          })
        Text("男")
          .margin({ left: 5, right: 15 })

        Radio({ value: 'female', group: 'gender' })
          .checked(this.gender === 'female')
          .onChange((isChecked: boolean) => {
            if (isChecked) this.gender = 'female';
          })
        Text("女")
          .margin({ left: 5 })
      }
      .width("90%")
      .margin({ bottom: 15 })

      // 角色选择
      Row() {
        Text("角色：")
          .fontSize(18)
          .margin({ right: 15 })

        Radio({ value: 'user', group: 'role' })
          .checked(this.role === 'user')
          .onChange((isChecked: boolean) => {
            if (isChecked) this.role = 'user';
          })
        Text("普通用户")
          .margin({ left: 5, right: 15 })

        Radio({ value: 'admin', group: 'role' })
          .checked(this.role === 'admin')
          .onChange((isChecked: boolean) => {
            if (isChecked) this.role = 'admin';
          })
        Text("管理员")
          .margin({ left: 5 })
      }
      .width("90%")
      .margin({ bottom: 15 })

      // 邮箱输入
      TextInput({ placeholder: "请输入邮箱" })
        .width("90%")
        .height(50)
        .margin({ bottom: 15 })
        .type(InputType.Email)
        .onChange((value: string) => {
          this.email = value.trim();
        })

      // 密码输入
      TextInput({ placeholder: "请输入密码 (至少8位)" })
        .width("90%")
        .height(50)
        .margin({ bottom: 10 })
        .type(InputType.Password)
        .onChange((value: string) => {
          this.password = value.trim();
          this.calculatePasswordStrength();
        })

      // 密码强度指示器
      Row() {
        ForEach([1, 2, 3, 4], (i: number) => {
          Column()
            .width("20%")
            .height(4)
            .margin({ right: 5 })
            .backgroundColor(i <= this.passwordStrength ?
              (i <= 2 ? "#FF5722" : i === 3 ? "#FFC107" : "#4CAF50") : "#E0E0E0")
        })
      }
      .width("90%")
      .margin({ bottom: 15 })

      // 确认密码
      TextInput({ placeholder: "请再次输入密码" })
        .width("90%")
        .height(50)
        .margin({ bottom: 25 })
        .type(InputType.Password)
        .onChange((value: string) => {
          this.confirmPassword = value.trim();
        })

      // 注册按钮
      Button(this.isProcessing ? "注册中..." : "立即注册")
        .width("80%")
        .height(45)
        .backgroundColor("#409EFF")
        .fontColor(Color.White)
        .fontSize(20)
        .enabled(!this.isProcessing)
        .onClick(() => {
          this.handleRegister();
        })

      // 已有账号？去登录
      Row() {
        Text("已有账号？")
          .fontColor("#666")

        Text("立即登录")
          .fontColor("#409EFF")
          .margin({ left: 8 })
          .onClick(() => {
            router.pushUrl({ url: 'pages/LoginPage' });
          })
      }
      .margin({ top: 20 })
    }
    .width("100%")
    .height("100%")
    .justifyContent(FlexAlign.Center)
    .padding(20)
    .backgroundColor(Color.White)
  }

  private calculatePasswordStrength(): void {
    let strength = 0;
    if (this.password.length >= 8) strength++;
    if (/[A-Z]/.test(this.password)) strength++;
    if (/[0-9]/.test(this.password)) strength++;
    if (/[^A-Za-z0-9]/.test(this.password)) strength++;
    this.passwordStrength = strength;
  }

  private handleRegister(): void {
    if (!this.validateInput()) return;

    this.isProcessing = true;
    this.userDatabase.checkUserExists(this.username, (exists) => {
      if (exists) {
        promptAction.showToast({ message: '用户名已存在', duration: 2000 });
        this.isProcessing = false;
        return;
      }

      this.userDatabase.insertUser({
        username: this.username,
        gender: this.gender,
        email: this.email,
        password: this.password,
        role: this.role
      }, (success) => {
        if (success) {
          promptAction.showToast({ message: '注册成功', duration: 2000 });
          setTimeout(() => {
            router.back({
              url: 'pages/LoginPage',
              params: {
                username: this.username,
                email: this.email
              }
            });
          }, 2000);
        } else {
          promptAction.showToast({ message: '注册失败', duration: 2000 });
        }
        this.isProcessing = false;
      });
    });
  }

  private validateInput(): boolean {
    if (!this.username || !this.password || !this.confirmPassword || !this.email) {
      promptAction.showToast({ message: '请填写完整信息', duration: 2000 });
      return false;
    }

    if (this.username.length < 3 || this.username.length > 20) {
      promptAction.showToast({ message: '用户名需3-20位字符', duration: 2000 });
      return false;
    }

    if (!/^[a-zA-Z0-9_]+$/.test(this.username)) {
      promptAction.showToast({ message: '用户名只能包含字母、数字和下划线', duration: 2000 });
      return false;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.email)) {
      promptAction.showToast({ message: '请输入有效的邮箱地址', duration: 2000 });
      return false;
    }

    if (this.password.length < 8) {
      promptAction.showToast({ message: '密码至少8位字符', duration: 2000 });
      return false;
    }

    if (this.password !== this.confirmPassword) {
      promptAction.showToast({ message: '两次密码输入不一致', duration: 2000 });
      return false;
    }

    return true;
  }
}
```

### 3. Management Page

#### 3.1 截图展示

<img
src=6.png>

#### 3.2 用例图与类图

<img src=类3.png>
<img src=用例3.png>

#### 3.3 代码实现

```typescript {.line-numbers}
import router from '@ohos.router';
import { BusinessError } from '@ohos.base';
import { relationalStoreDB } from '../model/RelationalDatabase';
import { UserType } from '../model/UserModel';
import promptAction from '@ohos.promptAction';
import { ValuesBucket } from '@kit.ArkData';

// 明确定义更新用户信息的接口
interface UserUpdateValues {
  gender: string;
  email: string;
  password: string;
  role: string;
}

// 定义对话框按钮类型
interface DialogButton {
  text: string;
  color: string;
}

// 定义对话框配置类型
interface DialogConfig {
  title: string;
  message: string;
  buttons: DialogButton[];
}



@Entry
@Component
struct ManagementPage {
  @State users: UserType[] = [];
  @State filteredUsers: UserType[] = [];
  @State isLoading: boolean = true;
  @State errorMessage: string = '';
  @State searchText: string = '';
  @State showEditDialog: boolean = false;
  @State currentUser: UserType = {
    username: '',
    gender: '',
    email: '',
    password: '',
    role: ''
  };

  aboutToAppear() {
    this.loadUsers();
  }

  // 加载用户数据
  async loadUsers() {
    this.isLoading = true;
    this.errorMessage = '';

    try {
      const users = await new Promise<UserType[]>((resolve) => {
        relationalStoreDB.queryAllUsers((users: UserType[]) => {
          resolve(users || []);
        });
      });
      this.users = users;
      this.filterUsers();
    } catch (error) {
      console.error(`查询用户失败: ${error instanceof Error ? error.message : JSON.stringify(error)}`);
      this.errorMessage = '加载用户数据失败，请稍后再试';
    } finally {
      this.isLoading = false;
    }
  }

  // 过滤用户数据
  filterUsers() {
    if (this.searchText.trim() === '') {
      this.filteredUsers = this.users.slice();
    } else {
      const searchTerm = this.searchText.toLowerCase();
      this.filteredUsers = this.users.filter(user => {
        const username = user.username ?? '';
        const email = user.email ?? '';
        const role = user.role ?? '';
        return username.toLowerCase().includes(searchTerm) ||
        email.toLowerCase().includes(searchTerm) ||
        role.toLowerCase().includes(searchTerm);
      });
    }
  }

  // 删除用户
  deleteUser(username: string) {
    const dialogConfig: DialogConfig = {
      title: '确认删除',
      message: `确定要删除用户 ${username} 吗？`,
      buttons: [
        { text: '取消', color: '#000000' },
        { text: '确定', color: '#ff4d4f' }
      ]
    };

    promptAction.showDialog(dialogConfig).then((result) => {
      if (result.index === 1) {
        relationalStoreDB.deleteUser(username, (success: boolean) => {
          if (success) {
            promptAction.showToast({ message: '删除成功', duration: 2000 });
            this.loadUsers();
          } else {
            promptAction.showToast({ message: '删除失败', duration: 2000 });
          }
        });
      }
    });
  }

  // 打开编辑对话框
  openEditDialog(user: UserType) {
    this.currentUser = {
      username: user.username ?? '',
      gender: user.gender ?? '',
      email: user.email ?? '',
      password: user.password ?? '',
      role: user.role ?? ''
    };
    this.showEditDialog = true;
  }

  // 保存用户信息
  saveUser() {
    const values: UserUpdateValues = {
      gender: this.currentUser.gender ?? '',
      email: this.currentUser.email ?? '',
      password: this.currentUser.password ?? '',
      role: this.currentUser.role ?? ''
    };

    // 确保 username 为 string 类型
    const username = this.currentUser.username ?? '';

    // 将 UserUpdateValues 转换为 ValuesBucket 类型
    const valuesBucket: ValuesBucket = {
      gender: values.gender,
      email: values.email,
      password: values.password,
      role: values.role
    };

    relationalStoreDB.updateUser(username, valuesBucket, (success: boolean) => {
      if (success) {
        promptAction.showToast({ message: '更新成功', duration: 2000 });
        this.showEditDialog = false;
        this.loadUsers();
      } else {
        promptAction.showToast({ message: '更新失败', duration: 2000 });
      }
    });
  }

  build() {
    Column() {
      // 顶部导航栏
      Row() {
        Button() {
          Image($r('app.media.ic_public_back'))
            .width(24)
            .height(24)
        }
        .width(36)
        .height(36)
        .backgroundColor('transparent')
        .onClick(() => {
          router.back();
        });

        Text('用户管理')
          .fontSize(20)
          .fontWeight(FontWeight.Medium)
          .margin({ left: 16 });

        Blank();

        Button('刷新')
          .height(36)
          .fontSize(16)
          .fontColor('#007DFF')
          .backgroundColor('transparent')
          .onClick(() => this.loadUsers());
      }
      .width('100%')
      .height(56)
      .padding({ left: 16, right: 16 })
      .backgroundColor('#FFFFFF');

      // 搜索框
      Row() {
        TextInput({ placeholder: '搜索用户名/邮箱/角色' })
          .width('80%')
          .height(40)
          .margin({ right: 10 })
          .onChange((value: string) => {
            this.searchText = value;
            this.filterUsers();
          });

        Button('搜索')
          .width('20%')
          .height(40)
          .onClick(() => this.filterUsers());
      }
      .width('100%')
      .padding(10)
      .backgroundColor('#FFFFFF');

      // 内容区域
      if (this.isLoading) {
        Column() {
          LoadingProgress()
            .width(50)
            .height(50)
            .color('#007DFF');
          Text('加载中...')
            .fontSize(16)
            .margin({ top: 16 });
        }
        .width('100%')
        .layoutWeight(1)
        .justifyContent(FlexAlign.Center);
      } else if (this.errorMessage) {
        Column() {
          Text(this.errorMessage)
            .fontSize(16)
            .fontColor(Color.Red);
          Button('重试')
            .margin({ top: 20 })
            .onClick(() => this.loadUsers());
        }
        .width('100%')
        .layoutWeight(1)
        .justifyContent(FlexAlign.Center);
      } else if (this.filteredUsers.length === 0) {
        Column() {
          Text(this.searchText ? '未找到匹配的用户' : '暂无用户数据')
            .fontSize(16)
            .fontColor('#999999');
        }
        .width('100%')
        .layoutWeight(1)
        .justifyContent(FlexAlign.Center);
      } else {
        Column() {
          // 表头
          Row() {
            Text('用户名')
              .width('15%')
              .fontWeight(FontWeight.Bold)
              .textAlign(TextAlign.Start);
            Text('性别')
              .width('15%')
              .fontWeight(FontWeight.Bold)
              .textAlign(TextAlign.Center);
            Text('邮箱')
              .width('20%')
              .fontWeight(FontWeight.Bold)
              .textAlign(TextAlign.Center);
            Text('角色')
              .width('15%')
              .fontWeight(FontWeight.Bold)
              .textAlign(TextAlign.Center);
            Text('操作')
              .width('35%')
              .fontWeight(FontWeight.Bold)
              .textAlign(TextAlign.Center);
          }
          .width('100%')
          .padding(10)
          .backgroundColor('#F0F0F0');

          // 用户列表
          List() {
            ForEach(this.filteredUsers, (user: UserType) => {
              ListItem() {
                Row() {
                  Text(user.username ?? '')
                    .width('15%')
                    .textAlign(TextAlign.Start);
                  Text(user.gender ?? '')
                    .width('15%')
                    .textAlign(TextAlign.Start);
                  Text(user.email ?? '')
                    .width('25%')
                    .textAlign(TextAlign.Start)
                    .textOverflow({ overflow: TextOverflow.Ellipsis })
                    .maxLines(1);
                  Text(user.role ?? '')
                    .width('15%')
                    .textAlign(TextAlign.Start);

                  // 操作按钮
                  Row() {
                    Button('编辑')
                      .width(60)
                      .height(30)
                      .fontSize(12)
                      .onClick(() => this.openEditDialog(user));

                    Button('删除')
                      .width(60)
                      .height(30)
                      .fontSize(12)
                      .backgroundColor('#ff4d4f')
                      .onClick(() => this.deleteUser(user.username ?? ''));
                  }
                  .width('35%')
                  .justifyContent(FlexAlign.Start);
                }
                .width('100%')
                .padding(10)
                .borderRadius(5);
              }
            });
          }
          .width('100%')
          .layoutWeight(1)
          .divider({ strokeWidth: 1, color: '#E0E0E0' });
        }
        .width('100%')
        .layoutWeight(1);
      }

      // 编辑对话框
      if (this.showEditDialog) {
        Column() {
          Column() {
            Text('编辑用户信息')
              .fontSize(18)
              .fontWeight(FontWeight.Bold)
              .margin({ bottom: 20 });

            Row() {
              Text('用户名:')
                .width('30%');
              Text(this.currentUser.username ?? '')
                .width('70%');
            }
            .margin({ bottom: 10 });

            Row() {
              Text('性别:')
                .width('30%');
              TextInput({ text: this.currentUser.gender ?? '' })
                .width('70%')
                .onChange((value: string) => {
                  this.currentUser.gender = value;
                });
            }
            .margin({ bottom: 10 });

            Row() {
              Text('邮箱:')
                .width('30%');
              TextInput({ text: this.currentUser.email ?? '' })
                .width('70%')
                .onChange((value: string) => {
                  this.currentUser.email = value;
                });
            }
            .margin({ bottom: 10 });

            Row() {
              Text('角色:')
                .width('30%');
              TextInput({ text: this.currentUser.role ?? '' })
                .width('70%')
                .onChange((value: string) => {
                  this.currentUser.role = value;
                });
            }
            .margin({ bottom: 20 });

            Row() {
              Button('取消')
                .width('40%')
                .margin({ right: 10 })
                .onClick(() => {
                  this.showEditDialog = false;
                });

              Button('保存')
                .width('40%')
                .backgroundColor('#007DFF')
                .onClick(() => {
                  this.saveUser();
                });
            }
            .justifyContent(FlexAlign.Center);
          }
          .width('80%')
          .padding(20)
          .backgroundColor('#FFFFFF')
          .borderRadius(10);
        }
        .width('100%')
        .height('100%')
        .justifyContent(FlexAlign.Center)
        .backgroundColor('rgba(0,0,0,0.5)')
        .onClick(() => {
          this.showEditDialog = false;
        });
      }
    }
    .width('100%')
    .height('100%')
    .backgroundColor('#F5F5F5');
  }
}
```
### 4. 其他相关代码
HomePage.ets
```typescript {.line-numbers}
@Entry
@Component
struct HomePage {
  build() {
    Column() {
      Text('欢迎')
        .fontSize(30)
        .fontWeight(FontWeight.Bold)
        .margin({ top: 100 })
    }
    .width('100%')
    .height('100%')
    .justifyContent(FlexAlign.Center)
    .alignItems(HorizontalAlign.Center)
  }
} 
```
AppContext.ets
```typescript {.line-numbers}
// 导入数据库操作类
import { relationalStoreDB } from './RelationalDatabase';
import app from '@ohos.app.ability.common';

// 应用上下文类，用于全局管理应用状态和数据库
export class AppContext {
  private static instance: AppContext;
  private context: app.Context | null = null;
  private isInitialized: boolean = false;

  // 私有构造函数，实现单例模式
  private constructor() {}

  // 获取单例实例
  public static getInstance(): AppContext {
    if (!AppContext.instance) {
      AppContext.instance = new AppContext();
    }
    return AppContext.instance;
  }

  // 初始化数据库
  public initDatabase(context: app.Context) {
    if (this.isInitialized) {
      return;
    }

    this.context = context;

    // 初始化数据库
    relationalStoreDB.initStoreRDB(context, 'Users');

    this.isInitialized = true;
    console.info('应用上下文初始化完成');
  }

  // 获取上下文
  public getContext(): app.Context | null {
    return this.context;
  }

  // 判断是否已初始化
  public isDbInitialized(): boolean {
    return this.isInitialized;
  }
}

// 导出单例
export const appContext = AppContext.getInstance();
```
RelationalDatabase.ets

```typescript {.line-numbers}
// 导入ArkUI关系型数据库模块
import { relationalStore } from "@kit.ArkData";
// 导入业务错误类型
import { BusinessError } from "@kit.BasicServicesKit";
// 导入用户数据类型定义
import { UserType } from "./UserModel";

// 数据库操作类
export class RelationalStoreDB {
  // 内存数据缓存
  Data: UserType[] = []
  // 静态数据库实例
  static rdbStore: relationalStore.RdbStore | null = null
  // 登录失败次数统计
  loginFailCount: Map<string, number> = new Map<string, number>();

  // 初始化数据库方法
  initStoreRDB(context: Context, tableName: string) {
    // 数据库配置对象
    const STORE_CONFIG: relationalStore.StoreConfig = {
      name: 'UserDB.db',        // 数据库文件名
      securityLevel: relationalStore.SecurityLevel.S1, // S1级安全加密
    }

    // 建表SQL语句
    const SQL_CREATE_TABLE = 'CREATE TABLE IF NOT EXISTS Users' +
      ' (' +
      'id INTEGER PRIMARY KEY AUTOINCREMENT,' +  // 用户ID，自增主键
      'username VARCHAR(255) UNIQUE,' +   // 用户名，唯一
      'gender VARCHAR(10),' +      // 性别
      'email VARCHAR(255),' +      // 邮箱
      'password VARCHAR(255),' +   // 密码
      'role VARCHAR(20)' +        // 角色
      ')';

    // 获取数据库实例
    relationalStore.getRdbStore(context, STORE_CONFIG, (err, store) => {
      if (err) {
        console.error(`获取RdbStore失败. Code:${err.code}, message:${err.message}`);
        return;
      }
      console.info('获取RdbStore成功.');
      RelationalStoreDB.rdbStore = store
      // 执行建表语句
      store.executeSql(SQL_CREATE_TABLE, (err) => {
        if (err) {
          console.error(`${tableName}创建失败 Code:${err.code}, message:${err.message}`);
          return;
        }
        console.info(`${tableName}创建成功`);
      }); // 闭合executeSql回调
    }); // 闭合getRdbStore回调
  } // 闭合initStoreRDB方法

  // 插入用户数据（使用回调方式）
  insertUser(user: UserType, callback?: (success: boolean) => void) {
    if (RelationalStoreDB.rdbStore === null) {
      console.error('数据库未初始化');
      if (callback) callback(false);
      return;
    }

    // 创建查询谓词检查用户是否存在
    let predicates = new relationalStore.RdbPredicates('Users');
    predicates.equalTo('username', user.username);

    RelationalStoreDB.rdbStore.query(predicates, null, (err, resultSet) => {
      if (err) {
        console.error(`查询用户失败. Code:${err.code}, message:${err.message}`);
        if (callback) callback(false);
        return;
      }

      if (resultSet.goToFirstRow()) {
        console.error('用户名已存在');
        resultSet.close();
        if (callback) callback(false);
        return;
      }
      resultSet.close();

      // 构建数据对象
      const userData: relationalStore.ValuesBucket = {
        username: user.username ?? '',
        gender: user.gender ?? '',
        email: user.email ?? '',
        password: user.password ?? '',
        role: user.role ?? ''
      };

      // 执行插入，使用非空断言操作符 ! 避免null检查
      RelationalStoreDB.rdbStore!.insert('Users', userData, (err, rowId) => {
        if (err) {
          console.error(`插入用户失败. Code:${err.code}, message:${err.message}`);
          if (callback) callback(false);
          return;
        }
        console.info(`插入用户成功, rowId: ${rowId}`);
        if (callback) callback(true);
      }); // 闭合insert回调
    }); // 闭合query回调
  }

  // 验证用户登录（使用回调方式）
  verifyLogin(username: string, password: string, role: string, callback: (success: boolean) => void) {
    if (RelationalStoreDB.rdbStore === null) {
      console.error('数据库未初始化');
      callback(false);
      return;
    }

    // 构建查询条件
    let predicates = new relationalStore.RdbPredicates('Users');
    predicates.equalTo('username', username).and().equalTo('role', role);

    // 执行查询
    RelationalStoreDB.rdbStore!.query(predicates, null, (err, resultSet) => {
      if (err) {
        console.error(`验证登录失败. Code:${err.code}, message:${err.message}`);
        callback(false);
        return;
      }

      if (resultSet.goToFirstRow()) {
        // 获取密码
        const storedPassword = resultSet.getString(resultSet.getColumnIndex('password'));
        resultSet.close();

        // 直接比较密码
        callback(storedPassword === password);
      } else {
        resultSet.close();
        callback(false); // 用户不存在
      }
    }); // 闭合query回调
  }

  // 查询所有用户（使用回调方式）
  queryAllUsers(callback: (users: UserType[]) => void) {
    if (RelationalStoreDB.rdbStore === null) {
      console.error('数据库未初始化');
      callback([]);
      return;
    }

    let users: UserType[] = [];

    // 创建查询条件
    let predicates = new relationalStore.RdbPredicates('Users');

    // 执行查询
    RelationalStoreDB.rdbStore!.query(predicates, null, (err, resultSet) => {
      if (err) {
        console.error(`查询用户失败. Code:${err.code}, message:${err.message}`);
        callback([]);
        return;
      }

      // 处理查询结果
      while (resultSet.goToNextRow()) {
        const username = resultSet.getString(resultSet.getColumnIndex('username'));
        const gender = resultSet.getString(resultSet.getColumnIndex('gender'));
        const email = resultSet.getString(resultSet.getColumnIndex('email'));
        const password = resultSet.getString(resultSet.getColumnIndex('password'));
        const role = resultSet.getString(resultSet.getColumnIndex('role'));

        users.push({
          username: username,
          gender: gender,
          email: email,
          password: password, // 注意：在实际应用中不应该返回密码
          role: role
        });
      }

      resultSet.close();
      this.Data = users;
      callback(users);
    }); // 闭合query回调
  }

  // 删除用户
  deleteUser(username: string, callback?: (success: boolean) => void) {
    if (RelationalStoreDB.rdbStore === null) {
      console.error('数据库未初始化');
      if (callback) callback(false);
      return;
    }

    // 创建删除谓词
    let predicates = new relationalStore.RdbPredicates('Users');
    // 设置过滤条件
    predicates.equalTo('username', username);

    // 执行删除
    RelationalStoreDB.rdbStore!.delete(predicates, (err, rows) => {
      if (err) {
        console.error(`删除用户失败. Code:${err.code}, message:${err.message}`);
        if (callback) callback(false);
        return;
      }
      console.info(`删除用户成功: ${rows}行受影响`);
      if (callback) callback(true);
    }); // 闭合delete回调
  }

  // 更新用户信息
  updateUser(username: string, userData: relationalStore.ValuesBucket, callback?: (success: boolean) => void) {
    if (RelationalStoreDB.rdbStore === null) {
      console.error('数据库未初始化');
      if (callback) callback(false);
      return;
    }

    // 创建更新谓词
    let predicates = new relationalStore.RdbPredicates('Users');
    // 设置过滤条件
    predicates.equalTo('username', username);

    // 执行更新
    RelationalStoreDB.rdbStore!.update(userData, predicates, (err, rows) => {
      if (err) {
        console.error(`更新用户失败. Code:${err.code}, message:${err.message}`);
        if (callback) callback(false);
        return;
      }
      console.info(`更新用户成功: ${rows}行受影响`);
      if (callback) callback(true);
    }); // 闭合update回调
  }

  // 检查用户是否存在
  checkUserExists(username: string, callback: (exists: boolean) => void) {
    if (RelationalStoreDB.rdbStore === null) {
      console.error('数据库未初始化');
      callback(false);
      return;
    }

    let predicates = new relationalStore.RdbPredicates('Users');
    predicates.equalTo('username', username);

    RelationalStoreDB.rdbStore!.query(predicates, null, (err, resultSet) => {
      if (err) {
        console.error(`检查用户是否存在失败. Code:${err.code}, message:${err.message}`);
        callback(false);
        return;
      }

      const exists = resultSet.goToFirstRow();
      resultSet.close();
      callback(exists);
    }); // 闭合query回调
  }

  // 记录登录失败次数
  recordLoginFailure(username: string): number {
    const count = (this.loginFailCount.get(username) || 0) + 1;
    this.loginFailCount.set(username, count);
    return count;
  }

  // 重置登录失败次数
  resetLoginFailure(username: string): void {
    this.loginFailCount.delete(username);
  }

  // 获取登录失败次数
  getLoginFailCount(username: string): number {
    return this.loginFailCount.get(username) || 0;
  }
}

// 创建单例实例
const relationalStoreDB = new RelationalStoreDB()
// 导出实例
export { relationalStoreDB }
```
UserModel.ets
```typescript {.line-numbers}
// 用户数据类型定义（用于规范用户数据格式）
export class UserType {
  // 用户名
  username?: string;

  // 性别
  gender?: string;

  // 邮箱
  email?: string;

  // 密码
  password?: string;

  // 角色（用户/管理员）
  role?: string;
}
```