# <center> <font face="仿宋">实验一实验报告</font></center>
  <center><font face ="楷体">3225706010 空数1班 黄境琴</font></center>   
  
  ***
  ### 一、过程与结果展示
#### **1. 创建工程**
在菜单栏通过File > New > Create Project创建一个新工程，并且选择Empty Ability模板，点击Next进行下一步配置
  ![图1](image.png)

#### **2. 基础设置** 
设置好Project name与文件存放位置，命名通常使用英文与“_”进行组合，Compatible SDK指应用程序兼容的最低软件开发工具包版本
  ![图2](image-1.png)  

#### **3. ArkTS工程目录结构分析** 
  ![图3](image-2.png)
  
 - **AppScope > app.json5**：应用的全局配置信息，定义应用程序的基本信息和属性
  - **entry：**  
      + **src > main > ets**：存放ArkTS的源码文件。这是开发过程中的核心部分，包含了实现应用功能的TypeScript代码
      + **src > main > ets > entryability**：应用/服务的入口
      + **src > main > ets > entrybackupability**：应用提供扩展的备份恢复能力
      + **src > main > ets > pages**：应用/服务包含的页面
      + **src > main > resources**：用于存放应用/服务所用到的资源文件
      + **src > main > module.json5**：模块配置文件。主要包含HAP包的配置信息、应用/服务在具体设备上的配置信息以及应用/服务的全局配置信息
      + **build-profile.json5**：当前的模块信息 、编译信息配置项，包括buildOption、targets配置等
      + **hvigorfile.ts**：模块级编译构建任务脚本
      + **obfuscation-rules.txt**：混淆规则文件
      + **oh-package.json5**：用来描述包名、版本、入口文件（类型声明文件）和依赖项等信息
  - **oh_modules**：用于存放三方库依赖信息
  - **build-profile.json5**：工程级配置信息，包括签名signingConfigs、产品配置products等。其中products中可配置当前运行环境，默认为HarmonyOS
  - **hvigorfile.ts**：工程级编译构建任务脚本
  - **oh-package.json5**：主要用来描述全局配置，如：依赖覆盖（overrides）、依赖关系重写（overrideDependencyMap）和参数化配置（parameterFile）等  
  
#### **4. 构建第一个页面 (Index)** 
  4.1 基础框架搭建
```Json5 {.line-numbers}
@Entry
@Component
struct Index {
  @State message: string = 'Index页面'

  build() {
    Row() {
      Column() {
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)
      }
      .width('100%')
    }
    .height('100%')
  }
}
```

 4.2 按钮组件集成（静态）
```Json5 {.line-numbers}
        Button() {
          Text('跳转')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        .type(ButtonType.Capsule)
```
4.3 动态功能实现（路由跳转）
```Json5 {.line-numbers}
 .onClick(() => {
          console.info(`Succeeded in clicking the 'Next' button.`)
          router.pushUrl({ url: 'pages/Second' }).then(() => {
            console.info('Succeeded in jumping to the second page.')

          }).catch((err: BusinessError) => {
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)
          })
        }) 
```

4.4 预览页面
  ![图4](<[T1%N{0VMCFAH_WH$(XV7}5.png>)


#### **5. 构建第二个页面 (Second)**
  5.1 页面基础结构
  参照Index界面，新建一个初始界面，添加Text组件、Button组件等

  ```Json5 {.line-numbers}
@Entry
@Component
struct Second {
  @State message: string = 'Second页面'

  build() {
    Row() {
      Column() {
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)
        Button() {
          Text('返回')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        .type(ButtonType.Capsule)
        .margin({
          top: 20
        })
        .backgroundColor('#0D9FFB')
        .width('40%')
        .height('5%')
      }
      .width('100%')
    }
    .height('100%')
  }
}
```
5.2 返回功能实现
```Json5 {.line-numbers}
 .onClick(() => {
          console.info(`Succeeded in clicking the 'Back' button.`)
          try {
            // 返回第一页
            router.back()
            console.info('Succeeded in returning to the first page.')
          } catch (err) {
            let code = (err as BusinessError).code;
            let message = (err as BusinessError).message;
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`)
          }
        })
```

5.3 预览页面
 ![图5](<1H]VDA8MU)X`J]8P(~(IR9S.png>)

#### **6. Log（日志页面显示内容）** 
![图6](<[X74AXB7V8}{E27%)BOXXJR.png>)

***

### 二、代码与注释
#### **1. Index界面**
```Json5 {.line-numbers}
import { router } from '@kit.ArkUI';  // 导入ArkUI框架中的router模块，用于页面路由管理
import { BusinessError } from '@kit.BasicServicesKit';  // 导入BasicServicesKit中的BusinessError类，用于处理业务错误

@Entry  // 标记当前组件为应用的入口组件
@Component  // 标记当前结构体为ArkUI组件
struct Index {  // 定义一个名为Index的结构体组件
  @State message: string = 'Index页面'  // 使用@State装饰器定义一个响应式状态变量message，初始值为'Index页面'

  build() {  // 定义组件的UI构建方法
    Row() {  // 创建一个行布局容器
      Column() {  // 创建一个列布局容器
        Text(this.message)  // 创建一个文本组件，显示message的内容
          .fontSize(50)  // 设置文本字体大小为50
          .fontWeight(FontWeight.Bold)  // 设置文本字体加粗
        // 添加按钮，以响应用户点击
        Button() {  // 创建一个按钮组件
          Text('跳转')  // 按钮内部的文本内容为'跳转'
            .fontSize(30)  // 设置按钮文本字体大小为30
            .fontWeight(FontWeight.Bold)  // 设置按钮文本字体加粗
        }  // Button组件的右括号
        .type(ButtonType.Capsule)  // 设置按钮类型为胶囊形状
        .margin({  // 设置按钮的外边距
          top: 20  // 上边距为20
        })  // margin对象的右括号
        .backgroundColor('#0D9FFB')  // 设置按钮的背景颜色为#0D9FFB
        .width('40%')  // 设置按钮的宽度为父容器的40%
        .height('5%')  // 设置按钮的高度为父容器的5%
        // 跳转按钮绑定onClick事件，点击时跳转到第二页
        .onClick(() => {  // 绑定按钮的点击事件
          console.info(`Succeeded in clicking the 'Next' button.`)  // 打印日志，表示按钮点击成功
          // 跳转到第二页
          router.pushUrl({ url: 'pages/Second' }).then(() => {  // 调用router.pushUrl方法，跳转到'pages/Second'页面
            console.info('Succeeded in jumping to the second page.')  // 打印日志，表示跳转成功
          }).catch((err: BusinessError) => {  // 捕获跳转过程中可能发生的错误
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)  // 打印错误日志，包含错误码和错误信息
          })  // catch块的右括号
        })  // onClick事件的右括号
      }  // Column组件的右括号
      .width('100%')  // 设置列布局容器的宽度为100%
    }  // Row组件的右括号
    .height('100%')  // 设置行布局容器的高度为100%
  }  // build方法的右括号
}  // Index结构体的右括号

```

#### **2. Second界面**
```Json5 {.line-numbers}
import { router } from '@kit.ArkUI';  // 导入ArkUI框架中的router模块，用于页面路由管理
import { BusinessError } from '@kit.BasicServicesKit';  // 导入BasicServicesKit中的BusinessError类，用于处理业务错误

@Entry  // 标记当前组件为应用的入口组件
@Component  // 标记当前结构体为ArkUI组件
struct Second {  // 定义一个名为Second的结构体组件
  @State message: string = 'Second页面'  // 使用@State装饰器定义一个响应式状态变量message，初始值为'Second页面'

  build() {  // 定义组件的UI构建方法
    Row() {  // 创建一个行布局容器
      Column() {  // 创建一个列布局容器
        Text(this.message)  // 创建一个文本组件，显示message的内容
          .fontSize(50)  // 设置文本字体大小为50
          .fontWeight(FontWeight.Bold)  // 设置文本字体加粗
        Button() {  // 创建一个按钮组件
          Text('返回')  // 按钮内部的文本内容为'返回'
            .fontSize(30)  // 设置按钮文本字体大小为30
            .fontWeight(FontWeight.Bold)  // 设置按钮文本字体加粗
        }  // Button组件的右括号
        .type(ButtonType.Capsule)  // 设置按钮类型为胶囊形状
        .margin({  // 设置按钮的外边距
          top: 20  // 上边距为20
        })  // margin对象的右括号
        .backgroundColor('#0D9FFB')  // 设置按钮的背景颜色为#0D9FFB
        .width('40%')  // 设置按钮的宽度为父容器的40%
        .height('5%')  // 设置按钮的高度为父容器的5%
        // 返回按钮绑定onClick事件，点击按钮时返回到第一页
        .onClick(() => {  // 绑定按钮的点击事件
          console.info(`Succeeded in clicking the 'Back' button.`)  // 打印日志，表示按钮点击成功
          try {  // 尝试执行以下代码
            // 返回第一页
            router.back()  // 调用router.back方法，返回上一页
            console.info('Succeeded in returning to the first page.')  // 打印日志，表示返回成功
          } catch (err) {  // 捕获返回过程中可能发生的错误
            let code = (err as BusinessError).code;  // 将错误转换为BusinessError类型，并获取错误码
            let message = (err as BusinessError).message;  // 获取错误信息
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`)  // 打印错误日志，包含错误码和错误信息
          }  // catch块的右括号
        })  // onClick事件的右括号
      }  // Column组件的右括号
      .width('100%')  // 设置列布局容器的宽度为100%
    }  // Row组件的右括号
    .height('100%')  // 设置行布局容器的高度为100%
  }  // build方法的右括号
}  // Second结构体的右括号
```

***

### 三、所使用函数总结说明
#### HarmonyOS API 使用总结
#### **1. 路由管理API**
1.1 **router.pushUrl()**
   `router.pushUrl(options: RouterOptions): Promise<void>`
   - **功能:** 导航到指定页面
   - **参数:**
     + url: 目标页面路径 (e.g. 'pages/Second')
     + params: 可选参数对象
   - **返回值:** Promise对象
  
   1.2 **router.back()**
   `router.back(options?: BackOptions): void`
   - **功能:** 返回上一页面
   - **参数:**
     + options: {
        url?: string // 指定返回目标页面
          }

   - **异常:** 当路由栈为空时抛出BusinessError

#### **2. 组件装饰器**
   2.1 **@Entry**
   `@Entry`
   - **功能:** 导航到指定页面
   - **特性:**
     + 每个页面必须有且仅有一个@Entry组件
     + 作为页面入口节点

  2.2 **@Component**

```
    @Component 
    struct MyComponent {}
```

  - **功能:** 定义自定义组件
  - **要求:**
     + 必须与struct配合使用。
     + 组件必须实现build方法

#### **3. 状态管理**
   3.1 **@State**
   `@State message: string = 'Hello'`
  - **功能:** 组件内部状态管理
  - **特性:**
    + 状态变化自动触发UI更新
    + 支持基本数据类型和类对象

#### 常用API与组件
#### **4. 布局组件:**
   4.1 **Row() 和 Column()**
  - **功能:** 用于布局。Row表示行布局，Column表示列布局

   4.2 **Text()**
  - **功能:** 用于显示文本内容

   4.3 **Button()**
   - **功能:** 用于创建按钮组件
  - **事件绑定:** `Button.onClick()`，用于为按钮绑定点击事件，当用户点击按钮时触发

#### **5. 日志输出**

   5.1 **console.info()**
  - **功能:** 用于在控制台输出信息日志，通常用于调试或记录操作成功的信息

   5.2 **console.error()**
  - **功能:** 用于在控制台输出错误日志，通常用于捕获并记录操作失败的信息

#### **6.  错误处理**

  6.1 **BusinessError**

  - **功能:** 用于表示业务错误，包含错误码和错误信息
  - **属性:**
    +  `code`: 错误码，用于标识错误的类型
    + `message`: 错误信息，描述错误的详细信息